﻿using System;
using System.Collections.Generic;
using System.Data;
using Capa_AccesoDatos;

namespace Capa_LogicaDeNegocios
{
    public class Cls_Facturas
    {
        public int C_IdFactura { get; set; }
        public DateTime C_DtmFecha { get; set; }
        public int C_IdCliente { get; set; }
        public int C_IdEmpleado { get; set; }
        public double C_NumDescuento { get; set; }
        public double C_NumImpuesto { get; set; }
        public double C_NumValorTotal { get; set; }
        public int C_IdEstado { get; set; }
        public string C_StrUsuarioModifica { get; set; }

        Cls_Acceso_Datos AccesoDatos = new Cls_Acceso_Datos();

        public DataTable Consulta_Factura()
        {
            try
            {
                string sentencia =
                    "select f.IdFactura, c.StrNombre, f.DtmFecha, f.NumValorTotal " +
                    "from TBLFACTURA f " +
                    "join TBLCLIENTES c on f.IdCliente = c.IdCliente";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Consulta_Factura(int IdFactura)
        {
            try
            {
                string sentencia =
                    "select f.*, c.StrNombre " +
                    "from TBLFACTURA f " +
                    "join TBLCLIENTES c on f.IdCliente = c.IdCliente " +
                    $"where f.IdFactura={IdFactura}";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Filtrar_Factura(string filtro)
        {
            try
            {
                string sentencia =
                    "select f.IdFactura, c.StrNombre, f.DtmFecha, f.NumValorTotal " +
                    "from TBLFACTURA f " +
                    "join TBLCLIENTES c on f.IdCliente = c.IdCliente " +
                    $"where c.StrNombre like '%{filtro}%'";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public int BuscarIdCliente(string nombre)
        {
            try
            {
                DataTable dt = AccesoDatos.EjecutarConsulta(
                    $"select IdCliente from TBLCLIENTES where StrNombre='{nombre}'");
                if (dt != null && dt.Rows.Count > 0)
                    return Convert.ToInt32(dt.Rows[0][0]);
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public string EliminarFactura()
        {
            string mensaje = "";
            try
            {
                AccesoDatos.EjecutarComando(
                    $"delete from TBLDETALLE_FACTURA where IdFactura={C_IdFactura}");
                mensaje = AccesoDatos.EjecutarComando(
                    $"delete from TBLFACTURA where IdFactura={C_IdFactura}");
            }
            catch (Exception ex)
            {
                mensaje = "FALLO BORRADO EN FACTURA " + ex.Message;
            }
            return mensaje;
        }

        public string ActualizarFactura()
        {
            string mensaje = "";
            try
            {
                List<Cls_parametros> lst = new List<Cls_parametros>();
                lst.Add(new Cls_parametros("@IdFactura", C_IdFactura));
                lst.Add(new Cls_parametros("@DtmFecha", C_DtmFecha));
                lst.Add(new Cls_parametros("@IdCliente", C_IdCliente));
                lst.Add(new Cls_parametros("@IdEmpleado", C_IdEmpleado));
                lst.Add(new Cls_parametros("@NumDescuento", C_NumDescuento));
                lst.Add(new Cls_parametros("@NumImpuesto", C_NumImpuesto));
                lst.Add(new Cls_parametros("@NumValorTotal", C_NumValorTotal));
                lst.Add(new Cls_parametros("@IdEstado", C_IdEstado));
                lst.Add(new Cls_parametros("@DtmFechaModifica", DateTime.Now));
                lst.Add(new Cls_parametros("@StrUsuarioModifica", C_StrUsuarioModifica));
                mensaje = AccesoDatos.Ejecutar_procedimiento("actualizar_Factura", lst);
            }
            catch (Exception ex)
            {
                mensaje = "FALLO LA ACTUALIZACION FACTURA " + ex.Message;
            }
            return mensaje;
        }
    }
}
