﻿using System;
using System.Collections.Generic;
using System.Data;
using Capa_AccesoDatos;

namespace Capa_LogicaDeNegocios
{
    public class Cls_Productos
    {
        public int C_IdProducto { get; set; }
        public string C_StrNombre { get; set; }
        public string C_StrCodigo { get; set; }
        public double C_NumPrecioCompra { get; set; }
        public double C_NumPrecioVenta { get; set; }
        public int C_IdCategoria { get; set; }
        public string C_StrDetalle { get; set; }
        public string C_strFoto { get; set; }
        public int C_NumStock { get; set; }
        public string C_StrUsuarioModifica { get; set; }

        Cls_Acceso_Datos AccesoDatos = new Cls_Acceso_Datos();

        public DataTable Consulta_Producto()
        {
            try
            {
                string sentencia =
                    "select p.IdProducto, p.StrNombre, c.StrDescripcion, p.NumPrecioVenta, p.NumStock " +
                    "from TBLPRODUCTO p " +
                    "join TBLCATEGORIA_PROD c on p.IdCategoria = c.IdCategoria";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Consulta_Producto(int IdProducto)
        {
            try
            {
                string sentencia = $"Select * from TBLPRODUCTO where IdProducto={IdProducto}";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Filtrar_Producto(string filtro)
        {
            try
            {
                string sentencia =
                    "select p.IdProducto, p.StrNombre, c.StrDescripcion, p.NumPrecioVenta, p.NumStock " +
                    "from TBLPRODUCTO p " +
                    "join TBLCATEGORIA_PROD c on p.IdCategoria = c.IdCategoria " +
                    $"where p.StrNombre like '%{filtro}%'";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable ConsultarCategoria()
        {
            try
            {
                return AccesoDatos.EjecutarConsulta("Select * from TBLCATEGORIA_PROD");
            }
            catch
            {
                return null;
            }
        }

        public string EliminarProducto()
        {
            string mensaje = "";
            try
            {
                List<Cls_parametros> lst = new List<Cls_parametros>();
                lst.Add(new Cls_parametros("@IdProducto", C_IdProducto));
                mensaje = AccesoDatos.Ejecutar_procedimiento("Eliminar_Producto", lst);
            }
            catch (Exception ex)
            {
                mensaje = "FALLO BORRADO EN PRODUCTO " + ex.Message;
            }
            return mensaje;
        }

        public string ActualizarProducto()
        {
            string mensaje = "";
            try
            {
                List<Cls_parametros> lst = new List<Cls_parametros>();
                lst.Add(new Cls_parametros("@IdProducto", C_IdProducto));
                lst.Add(new Cls_parametros("@StrNombre", C_StrNombre));
                lst.Add(new Cls_parametros("@StrCodigo", C_StrCodigo));
                lst.Add(new Cls_parametros("@NumPrecioCompra", C_NumPrecioCompra));
                lst.Add(new Cls_parametros("@NumPrecioVenta", C_NumPrecioVenta));
                lst.Add(new Cls_parametros("@IdCategoria", C_IdCategoria));
                lst.Add(new Cls_parametros("@StrDetalle", C_StrDetalle));
                lst.Add(new Cls_parametros("@strFoto", C_strFoto));
                lst.Add(new Cls_parametros("@NumStock", C_NumStock));
                lst.Add(new Cls_parametros("@DtmFechaModifica", DateTime.Now));
                lst.Add(new Cls_parametros("@StrUsuarioModifica", C_StrUsuarioModifica));
                mensaje = AccesoDatos.Ejecutar_procedimiento("actualizar_Producto", lst);
            }
            catch (Exception ex)
            {
                mensaje = "FALLO LA ACTUALIZACION PRODUCTO " + ex.Message;
            }
            return mensaje;
        }
    }
}