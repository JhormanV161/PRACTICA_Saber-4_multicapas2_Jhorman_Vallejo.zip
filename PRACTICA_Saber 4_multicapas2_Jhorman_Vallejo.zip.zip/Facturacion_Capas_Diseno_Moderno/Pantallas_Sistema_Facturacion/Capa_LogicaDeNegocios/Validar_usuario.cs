﻿using System;
using System.Data;
using Capa_AccesoDatos;

namespace Capa_LogicaDeNegocios
{
    public class Validar_usuario
    {
        public string C_StrUsuario { get; set; }
        public string C_StrClave { get; set; }
        public int C_IdEmpleado { get; set; }

        public void ValidarUsuario()
        {
            try
            {
                string sentencia =
                    $"SELECT IdEmpleado FROM TBLSEGURIDAD " +
                    $"WHERE StrUsuario='{C_StrUsuario}' AND StrClave='{C_StrClave}'";

                DataTable dt = new DataTable();
                Cls_Acceso_Datos Acceso = new Cls_Acceso_Datos();
                dt = Acceso.EjecutarConsulta(sentencia);

                if (dt != null && dt.Rows.Count > 0)
                    C_IdEmpleado = Convert.ToInt32(dt.Rows[0][0]);
                else
                    C_IdEmpleado = 0;
            }
            catch (Exception ex)
            {
                throw new Exception("Error en la consulta " + ex);
            }
        }
    }
}