﻿using System;
using System.Collections.Generic;
using System.Data;
using Capa_AccesoDatos;

namespace Capa_LogicaDeNegocios
{
    public class Cls_Empleados
    {
        public int C_IdEmpleado { get; set; }
        public string C_strNombre { get; set; }
        public double C_NumDocumento { get; set; }
        public string C_StrDireccion { get; set; }
        public string C_StrTelefono { get; set; }
        public string C_StrEmail { get; set; }
        public int C_IdRolEmpleado { get; set; }
        public DateTime C_DtmIngreso { get; set; }
        public DateTime C_DtmRetiro { get; set; }
        public string C_strDatosAdicionales { get; set; }
        public string C_StrUsuarioModifico { get; set; }

        Cls_Acceso_Datos AccesoDatos = new Cls_Acceso_Datos();

        public DataTable Consulta_Empleado()
        {
            try
            {
                string sentencia =
                    "select e.IdEmpleado, e.strNombre, e.NumDocumento, r.StrDescripcion " +
                    "from TBLEMPLEADO e " +
                    "join TBLROLES r on e.IdRolEmpleado = r.IdRolEmpleado";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Consulta_Empleado(int IdEmpleado)
        {
            try
            {
                string sentencia = $"Select * from TBLEMPLEADO where IdEmpleado={IdEmpleado}";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Filtrar_Empleado(string filtro)
        {
            try
            {
                string sentencia =
                    "select e.IdEmpleado, e.strNombre, e.NumDocumento, r.StrDescripcion " +
                    "from TBLEMPLEADO e " +
                    "join TBLROLES r on e.IdRolEmpleado = r.IdRolEmpleado " +
                    $"where e.strNombre like '%{filtro}%'";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable ConsultarRol()
        {
            try
            {
                return AccesoDatos.EjecutarConsulta("Select * from TBLROLES");
            }
            catch
            {
                return null;
            }
        }

        public string EliminarEmpleado()
        {
            string mensaje = "";
            try
            {
                List<Cls_parametros> lst = new List<Cls_parametros>();
                lst.Add(new Cls_parametros("@IdEmpleado", C_IdEmpleado));
                mensaje = AccesoDatos.Ejecutar_procedimiento("Eliminar_Empleado", lst);
            }
            catch (Exception ex)
            {
                mensaje = "FALLO BORRADO EN EMPLEADO " + ex.Message;
            }
            return mensaje;
        }

        public string ActualizarEmpleado()
        {
            string mensaje = "";
            try
            {
                List<Cls_parametros> lst = new List<Cls_parametros>();
                lst.Add(new Cls_parametros("@IdEmpleado", C_IdEmpleado));
                lst.Add(new Cls_parametros("@strNombre", C_strNombre));
                lst.Add(new Cls_parametros("@NumDocumento", C_NumDocumento));
                lst.Add(new Cls_parametros("@StrDireccion", C_StrDireccion));
                lst.Add(new Cls_parametros("@StrTelefono", C_StrTelefono));
                lst.Add(new Cls_parametros("@StrEmail", C_StrEmail));
                lst.Add(new Cls_parametros("@IdRolEmpleado", C_IdRolEmpleado));
                lst.Add(new Cls_parametros("@DtmIngreso", C_DtmIngreso));
                lst.Add(new Cls_parametros("@DtmRetiro", C_DtmRetiro));
                lst.Add(new Cls_parametros("@strDatosAdicionales", C_strDatosAdicionales));
                lst.Add(new Cls_parametros("@DtmFechaModifica", DateTime.Now));
                lst.Add(new Cls_parametros("@StrUsuarioModifico", C_StrUsuarioModifico));
                mensaje = AccesoDatos.Ejecutar_procedimiento("actualizar_Empleado", lst);
            }
            catch (Exception ex)
            {
                mensaje = "FALLO LA ACTUALIZACION EMPLEADO " + ex.Message;
            }
            return mensaje;
        }
    }
}