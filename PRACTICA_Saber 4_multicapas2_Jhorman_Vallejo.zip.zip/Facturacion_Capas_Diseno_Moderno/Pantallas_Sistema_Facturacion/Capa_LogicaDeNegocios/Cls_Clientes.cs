﻿using System;
using System.Collections.Generic;
using System.Data;
using Capa_AccesoDatos;

namespace Capa_LogicaDeNegocios
{
    public class Cls_Clientes
    {
        public int C_IdCliente { get; set; }
        public string C_StrNombre { get; set; }
        public double C_NumDocumento { get; set; }
        public string C_StrDireccion { get; set; }
        public string C_StrTelefono { get; set; }
        public string C_StrEmail { get; set; }
        public string C_StrUsuarioModifica { get; set; }

        Cls_Acceso_Datos AccesoDatos = new Cls_Acceso_Datos();

        public DataTable Consulta_Cliente()
        {
            try
            {
                string sentencia = "select IdCliente, StrNombre, NumDocumento, StrTelefono from TBLCLIENTES";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Consulta_Cliente(int IdCliente)
        {
            try
            {
                string sentencia = $"Select * from TBLCLIENTES where IdCliente={IdCliente}";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public DataTable Filtrar_Cliente(string filtro)
        {
            try
            {
                string sentencia =
                    "select IdCliente, StrNombre, NumDocumento, StrTelefono from TBLCLIENTES " +
                    $"where StrNombre like '%{filtro}%'";
                return AccesoDatos.EjecutarConsulta(sentencia);
            }
            catch
            {
                return null;
            }
        }

        public string EliminarCliente()
        {
            string mensaje = "";
            try
            {
                List<Cls_parametros> lst = new List<Cls_parametros>();
                lst.Add(new Cls_parametros("@IdCliente", C_IdCliente));
                mensaje = AccesoDatos.Ejecutar_procedimiento("Eliminar_Cliente", lst);
            }
            catch (Exception ex)
            {
                mensaje = "FALLO BORRADO EN CLIENTE " + ex.Message;
            }
            return mensaje;
        }

        public string ActualizarCliente()
        {
            string mensaje = "";
            try
            {
                List<Cls_parametros> lst = new List<Cls_parametros>();
                lst.Add(new Cls_parametros("@IdCliente", C_IdCliente));
                lst.Add(new Cls_parametros("@StrNombre", C_StrNombre));
                lst.Add(new Cls_parametros("@NumDocumento", C_NumDocumento));
                lst.Add(new Cls_parametros("@StrDireccion", C_StrDireccion));
                lst.Add(new Cls_parametros("@StrTelefono", C_StrTelefono));
                lst.Add(new Cls_parametros("@StrEmail", C_StrEmail));
                lst.Add(new Cls_parametros("@StrUsuarioModifica", C_StrUsuarioModifica));
                lst.Add(new Cls_parametros("@DtmFechaModifica", DateTime.Now));
                mensaje = AccesoDatos.Ejecutar_procedimiento("actualizar_Cliente", lst);
            }
            catch (Exception ex)
            {
                mensaje = "FALLO LA ACTUALIZACION CLIENTE " + ex.Message;
            }
            return mensaje;
        }
    }
}