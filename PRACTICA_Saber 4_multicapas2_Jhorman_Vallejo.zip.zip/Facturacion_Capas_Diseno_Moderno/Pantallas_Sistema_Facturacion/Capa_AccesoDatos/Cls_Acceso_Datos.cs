﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Capa_AccesoDatos
{
    public class Cls_parametros
    {
        public string Nombre { get; set; }
        public object Valor { get; set; }
        public SqlDbType TipoDato { get; set; }
        public Int32 Tamano { get; set; }
        public ParameterDirection Direccionparametro { get; set; }

        public Cls_parametros(string ObjNombre, object ObjValor)
        {
            Nombre = ObjNombre;
            Valor = ObjValor;
            Direccionparametro = ParameterDirection.Input;
        }

        public Cls_parametros(string ObjNombre, SqlDbType ObjTipoDato, Int32 ObjTamano)
        {
            Nombre = ObjNombre;
            TipoDato = ObjTipoDato;
            Tamano = ObjTamano;
            Direccionparametro = ParameterDirection.Output;
        }
    }

    public class Cls_Acceso_Datos
    {
        SqlConnection conexion;
        SqlCommand cmd;
        SqlDataReader LectorDatos = null;
        SqlDataAdapter da;
        DataTable dt;
        DataSet ds;

        public string AbrirBd()
        {
            string resultado = "";
            try
            {
                conexion = new SqlConnection(
                    "Data Source=localhost\\SQLEXPRESS;Initial Catalog=[DBFACTURAS];Integrated Security=true;TrustServerCertificate=true;");
                conexion.Open();
            }
            catch (Exception ex)
            {
                resultado = "ERROR: No se establecio la conexion con la Base de datos " + ex;
            }
            return resultado;
        }

        public string CerrarrBd()
        {
            string resultado = "";
            try
            {
                conexion.Close();
            }
            catch (Exception ex)
            {
                resultado = "ERROR: Fallo al Cerrar la conexion " + ex;
            }
            return resultado;
        }

        public string Ejecutar_procedimiento(string procedimiento, List<Cls_parametros> lst)
        {
            string salida = "";
            try
            {
                int retornado;
                AbrirBd();
                SqlCommand Comando = new SqlCommand(procedimiento, conexion);
                Comando.CommandType = CommandType.StoredProcedure;
                if (lst != null)
                {
                    for (int i = 0; i < lst.Count; i++)
                    {
                        if (lst[i].Direccionparametro == ParameterDirection.Input)
                        {
                            Comando.Parameters.AddWithValue(lst[i].Nombre, lst[i].Valor);
                        }
                        if (lst[i].Direccionparametro == ParameterDirection.Output)
                        {
                            Comando.Parameters.Add(lst[i].Nombre, lst[i].TipoDato, lst[i].Tamano).Direction =
                                ParameterDirection.Output;
                        }
                    }
                }
                retornado = Comando.ExecuteNonQuery();
                CerrarrBd();
                if (retornado > 0)
                    salida = "Los datos fueron Actualizados";
                else
                    salida = "Los datos no fueron Actualizados";
            }
            catch (Exception ex)
            {
                salida = "ERROR: Fallo la Operacion: " + ex;
            }
            return salida;
        }

        public string EjecutarComando(string sentencia)
        {
            string salida = "";
            try
            {
                int retornado;
                AbrirBd();
                cmd = new SqlCommand(sentencia, conexion);
                retornado = cmd.ExecuteNonQuery();
                CerrarrBd();
                if (retornado > 0)
                    salida = "Los datos fueron Actualizados";
                else
                    salida = "Los datos no fueron Actualizados";
            }
            catch (Exception ex)
            {
                salida = "ERROR: Fallo Operacion: " + ex;
            }
            return salida;
        }

        public DataTable EjecutarConsulta(string sentencia)
        {
            try
            {
                AbrirBd();
                da = new SqlDataAdapter(sentencia, conexion);
                dt = new DataTable();
                da.Fill(dt);
                CerrarrBd();
                return dt;
            }
            catch
            {
                return null;
            }
        }
    }
}