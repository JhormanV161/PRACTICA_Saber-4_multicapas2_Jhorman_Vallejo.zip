using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmListaFacturas : Form
    {
        public FrmListaFacturas()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable();
        Cls_Facturas factura = new Cls_Facturas();

        private void Llenar_Grid()
        {
            DgFacturas.Rows.Clear();
            dt = factura.Consulta_Factura();
            if (dt == null || dt.Rows.Count == 0)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgFacturas.Rows.Add(
                    row["IdFactura"],
                    row["StrNombre"],
                    row["DtmFecha"],
                    row["NumValorTotal"]);
            }
        }

        private void FrmListaFacturas_Load(object sender, EventArgs e)
        {
            Llenar_Grid();
        }

        private int ObtenerSiguienteId()
        {
            int max = 0;
            foreach (DataGridViewRow row in DgFacturas.Rows)
            {
                if (row.Cells["Id_Factura"].Value != null &&
                    int.TryParse(row.Cells["Id_Factura"].Value.ToString(), out int id) &&
                    id > max)
                {
                    max = id;
                }
            }
            return max + 1;
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            FrmEditarFacturas frm = new FrmEditarFacturas
            {
                IdFactura = 0,
                IdAsignado = ObtenerSiguienteId()
            };

            if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                Llenar_Grid();
        }

        private void DgFacturas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            string columna = DgFacturas.Columns[e.ColumnIndex].Name;
            int posActual = e.RowIndex;

            if (columna == "BtnBorrar")
            {
                if (MessageBox.Show("Seguro de borrar", "CONFIRMACION",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    factura.C_IdFactura = int.Parse(
                        DgFacturas.Rows[posActual].Cells["Id_Factura"].Value.ToString());
                    MessageBox.Show(factura.EliminarFactura());
                    Llenar_Grid();
                }
            }
            else if (columna == "BtnEditar")
            {
                FrmEditarFacturas frm = new FrmEditarFacturas
                {
                    IdFactura = int.Parse(
                        DgFacturas.Rows[posActual].Cells["Id_Factura"].Value.ToString())
                };

                if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                    Llenar_Grid();
            }

            DgFacturas.EndEdit();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            DgFacturas.Rows.Clear();
            if (TxtBuscarFactura.Text != "")
                dt = factura.Filtrar_Factura(TxtBuscarFactura.Text);
            else
                dt = factura.Consulta_Factura();

            if (dt == null)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgFacturas.Rows.Add(
                    row["IdFactura"],
                    row["StrNombre"],
                    row["DtmFecha"],
                    row["NumValorTotal"]);
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}