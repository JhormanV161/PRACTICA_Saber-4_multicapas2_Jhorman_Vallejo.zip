using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmListaEmpleados : Form
    {
        public FrmListaEmpleados()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable();
        Cls_Empleados empleado = new Cls_Empleados();

        private void Llenar_Grid()
        {
            DgEmpleados.Rows.Clear();
            dt = empleado.Consulta_Empleado();
            if (dt == null || dt.Rows.Count == 0)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgEmpleados.Rows.Add(
                    row["IdEmpleado"],
                    row["strNombre"],
                    row["NumDocumento"],
                    row["StrDescripcion"]);
            }
        }

        private void FrmListaEmpleados_Load(object sender, EventArgs e)
        {
            Llenar_Grid();
        }

        private int ObtenerSiguienteId()
        {
            int max = 0;
            foreach (DataGridViewRow row in DgEmpleados.Rows)
            {
                if (row.Cells["Id_Empleado"].Value != null &&
                    int.TryParse(row.Cells["Id_Empleado"].Value.ToString(), out int id) &&
                    id > max)
                {
                    max = id;
                }
            }
            return max + 1;
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            FrmEditarEmpleados frm = new FrmEditarEmpleados
            {
                IdEmpleado = 0,
                IdAsignado = ObtenerSiguienteId()
            };
            UiEstilo.PrepararDialogo(frm);

            if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                Llenar_Grid();
        }

        private void DgEmpleados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            string columna = DgEmpleados.Columns[e.ColumnIndex].Name;
            int posActual = e.RowIndex;

            if (columna == "BtnBorrar")
            {
                if (MessageBox.Show("Seguro de borrar", "CONFIRMACION",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    empleado.C_IdEmpleado = int.Parse(
                        DgEmpleados.Rows[posActual].Cells["Id_Empleado"].Value.ToString());
                    string resultado = empleado.EliminarEmpleado();

                    if (resultado.Contains("REFERENCE"))
                        MessageBox.Show("No se puede eliminar: el empleado tiene usuario o facturas asociadas.");
                    else
                        MessageBox.Show(resultado);

                    Llenar_Grid();
                }
            }
            else if (columna == "BtnEditar")
            {
                FrmEditarEmpleados frm = new FrmEditarEmpleados
                {
                    IdEmpleado = int.Parse(
                        DgEmpleados.Rows[posActual].Cells["Id_Empleado"].Value.ToString())
                };
                UiEstilo.PrepararDialogo(frm);

                if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                    Llenar_Grid();
            }

            DgEmpleados.EndEdit();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            DgEmpleados.Rows.Clear();
            if (TxtBuscarEmpleado.Text != "")
                dt = empleado.Filtrar_Empleado(TxtBuscarEmpleado.Text);
            else
                dt = empleado.Consulta_Empleado();

            if (dt == null)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgEmpleados.Rows.Add(
                    row["IdEmpleado"],
                    row["strNombre"],
                    row["NumDocumento"],
                    row["StrDescripcion"]);
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
