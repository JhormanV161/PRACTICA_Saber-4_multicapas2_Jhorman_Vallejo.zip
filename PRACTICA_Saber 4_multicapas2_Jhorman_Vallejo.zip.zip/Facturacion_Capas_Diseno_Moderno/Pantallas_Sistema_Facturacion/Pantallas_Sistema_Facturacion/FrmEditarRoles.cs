using System.Windows.Forms;
using System;
using System.Data;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmEditarRoles : Form
    {
        public int IdRol { get; set; }
        public int IdAsignado { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }

        public FrmEditarRoles()
        {
            InitializeComponent();
            UiEstilo.AplicarTitulo(LblTitulo);
            UiEstilo.AplicarEtiqueta(LblNombreRol);
            UiEstilo.AplicarEtiqueta(LblDescripcion);
            UiEstilo.AplicarBoton(BtnActualizar);
            UiEstilo.AplicarBoton(BtnSalir);
        }

        Acceso_datos Acceso = new Acceso_datos();

        private void FrmEditarRoles_Load(object sender, System.EventArgs e)
        {
            TxtIdRol.ReadOnly = true;

            if (IdRol == 0)
            {
                LblTitulo.Text = "INGRESO NUEVO ROL";
                TxtIdRol.Text = IdAsignado.ToString();
            }
            else
            {
                LblTitulo.Text = "MODIFICAR ROL";
                TxtIdRol.Text = IdRol.ToString();
                TxtNombre.Text = Nombre ?? string.Empty;
                TxtDescripcion.Text = Descripcion ?? string.Empty;
            }
        }

        private void BtnActualizar_Click(object sender, System.EventArgs e)
        {
            errorProvider1.Clear();
            if (string.IsNullOrWhiteSpace(TxtNombre.Text))
            {
                errorProvider1.SetError(TxtNombre, "El nombre es obligatorio.");
                return;
            }

            string sentencia;

            if (IdRol == 0)
                sentencia = $"insert into TBLROLES (StrDescripcion) values ('{TxtNombre.Text}')";
            else
                sentencia = $"update TBLROLES set StrDescripcion = '{TxtNombre.Text}' where IdRolEmpleado = {IdRol}";

            MessageBox.Show(Acceso.EjecutarComando(sentencia));
            DialogResult = DialogResult.OK;
            Close();
        }

        private void BtnSalir_Click(object sender, System.EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
