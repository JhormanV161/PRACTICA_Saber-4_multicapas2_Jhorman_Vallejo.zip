using System;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmAcercaDe : Form
    {
        public FrmAcercaDe()
        {
            InitializeComponent();
        }

        private void FrmAcercaDe_Load(object sender, EventArgs e)
        {
            LstProductos.Items.AddRange(new object[]
            {
                "Sistema de Facturacion 1.0",
                "Modulo Clientes",
                "Modulo Productos",
                "Modulo Categorias",
                "Modulo Facturas",
                "Modulo Informes",
                "Modulo Seguridad",
                "MaterialSkin 0.2.1"
            });
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnCopiarInfo_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(
                LblProducto.Text + Environment.NewLine +
                LblVersion.Text + Environment.NewLine +
                LblCopyright.Text);
            MessageBox.Show("Informacion copiada al portapapeles.", "Acerca de",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnInfoSistema_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                Environment.OSVersion.ToString() + Environment.NewLine +
                "Equipo: " + Environment.MachineName,
                "Informacion del sistema",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void BtnDxDiag_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("dxdiag.exe");
            }
            catch
            {
                MessageBox.Show("No se pudo abrir DxDiag.", "Acerca de",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LnkLicencia_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Licencia academica - uso educativo.", "Informacion de licencia",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void LnkTerminos_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Terminos de uso del sistema de facturacion academico.",
                "Terminos de licencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void LstProductos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
