using System;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmInformes : Form
    {
        public FrmInformes()
        {
            InitializeComponent();
            UiEstilo.AplicarTitulo(LblTitulo);
            UiEstilo.AplicarEtiqueta(LblSeleccioneInforme);
            UiEstilo.AplicarEtiqueta(LblOrdenar);
            UiEstilo.AplicarEtiqueta(LblFechaInicio);
            UiEstilo.AplicarEtiqueta(LblFechaFinal);
            UiEstilo.AplicarBoton(BtnGenerar);
            UiEstilo.AplicarBoton(BtnSalir);
        }

        private void FrmInformes_Load(object sender, EventArgs e)
        {
            CmbInforme.SelectedIndex = 0;
            CmbOrdenar.SelectedIndex = 0;
            DtpFechaInicio.Value = DateTime.Today.AddMonths(-1);
            DtpFechaFinal.Value = DateTime.Today;
        }

        private void BtnGenerar_Click(object sender, EventArgs e)
        {
            DgInforme.Rows.Clear();
            for (int i = 0; i < 8; i++)
            {
                DgInforme.Rows.Add(i + 1, $"Registro {i + 1}", $"{(i + 1) * 25000}");
            }
            MessageBox.Show("Informe generado.", "Informacion",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
