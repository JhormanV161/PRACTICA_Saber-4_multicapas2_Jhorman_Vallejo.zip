﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmPrincipal : MaterialForm
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void AbrirForm (Form FormHijo)
        {
            if (this.PnlContenedor.Controls.Count > 0)
            {
                Control anterior = this.PnlContenedor.Controls[0];
                this.PnlContenedor.Controls.RemoveAt(0);
                if (anterior is Form formAnterior)
                    formAnterior.Dispose();
            }
            FormHijo.TopLevel = false;
            FormHijo.FormBorderStyle = FormBorderStyle.None;
            FormHijo.Dock = DockStyle.Fill;
            this.PnlContenedor.Controls.Add(FormHijo);
            FormHijo.Show();
            FormHijo.BringToFront();
            FormHijo.Focus();
        }

        private void BtnClientes_Click(object sender, EventArgs e)
        {
            FrmListaClientes ListaCliente = new FrmListaClientes();
            AbrirForm(ListaCliente);
        }

        private void BtnProductos_Click(object sender, EventArgs e)
        {
            FrmListaProducto listaProductos = new FrmListaProducto();
            AbrirForm(listaProductos);
        }

        private void BtnCategorias_Click(object sender, EventArgs e)
        {
            FrmListaCategoria listaCategoria = new FrmListaCategoria();
            AbrirForm(listaCategoria);
        }

        private void BtnFacturas_Click(object sender, EventArgs e)
        {
            FrmListaFacturas listaFacturas = new FrmListaFacturas();
            AbrirForm(listaFacturas);
        }

        private void BtnInformes_Click(object sender, EventArgs e)
        {
            FrmInformes informes = new FrmInformes();
            AbrirForm(informes);
        }

        private void BtnEmpleados_Click(object sender, EventArgs e)
        {
            FrmListaEmpleados listaEmpleados = new FrmListaEmpleados();
            AbrirForm(listaEmpleados);
        }

        private void BtnRoles_Click(object sender, EventArgs e)
        {
            FrmListaRoles listaRoles = new FrmListaRoles();
            AbrirForm(listaRoles);
        }

        private void BtnSeguridad_Click(object sender, EventArgs e)
        {
            FrmAdminSeguridad seguridad = new FrmAdminSeguridad();
            AbrirForm(seguridad);
        }

        private void BtnAyuda_Click(object sender, EventArgs e)
        {
            FrmAyuda ayuda = new FrmAyuda();
            AbrirForm(ayuda);
        }

        private void BtnAcercaDe_Click(object sender, EventArgs e)
        {
            using (FrmAcercaDe acercaDe = new FrmAcercaDe())
            {
                acercaDe.ShowDialog(this);
            }
        }
    }
}
