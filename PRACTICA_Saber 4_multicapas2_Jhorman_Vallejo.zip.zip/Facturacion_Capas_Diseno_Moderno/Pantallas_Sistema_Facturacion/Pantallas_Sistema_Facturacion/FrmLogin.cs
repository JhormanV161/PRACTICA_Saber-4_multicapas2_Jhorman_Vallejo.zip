﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnValidar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtUsuario.Text) || string.IsNullOrWhiteSpace(TxtPassword.Text))
            {
                MessageBox.Show("Debe ingresar usuario y contraseña.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Validar_usuario Obj_validar = new Validar_usuario();
            Obj_validar.C_StrUsuario = TxtUsuario.Text;
            Obj_validar.C_StrClave = TxtPassword.Text;
            Obj_validar.ValidarUsuario();

            if (Obj_validar.C_IdEmpleado != 0)
            {
                MessageBox.Show("Datos de verificacion validos");
                FrmPrincipal PantallaPrincipal = new FrmPrincipal();
                PantallaPrincipal.FormClosed += (s, args) => Application.Exit();
                PantallaPrincipal.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("USUARIO Y CLAVE NO ENCONTRADOS");
                TxtUsuario.Text = "";
                TxtPassword.Text = "";
                TxtUsuario.Focus();
            }
        }
    }
}
