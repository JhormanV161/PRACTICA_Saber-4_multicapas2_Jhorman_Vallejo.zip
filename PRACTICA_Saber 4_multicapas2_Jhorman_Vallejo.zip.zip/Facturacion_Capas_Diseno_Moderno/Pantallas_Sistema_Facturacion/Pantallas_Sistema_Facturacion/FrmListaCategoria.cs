using System;
using System.Windows.Forms;
using System.Data;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmListaCategoria : Form
    {
        public FrmListaCategoria()
        {
            InitializeComponent();
        }

        Acceso_datos Acceso = new Acceso_datos();
        DataTable dt = new DataTable();

        private void Llenar_Grid()
        {
            DgCategorias.Rows.Clear();

            dt = Acceso.EjecutarComandoDatos("select IdCategoria, StrDescripcion from TBLCATEGORIA_PROD");
            if (dt == null)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgCategorias.Rows.Add(
                    row["IdCategoria"],
                    row["StrDescripcion"],
                    row["StrDescripcion"]);
            }
        }

        private void FrmListaCategoria_Load(object sender, EventArgs e)
        {
            Llenar_Grid();
        }

        private int ObtenerSiguienteId()
        {
            int max = 0;
            foreach (DataGridViewRow row in DgCategorias.Rows)
            {
                if (row.Cells["Id_Categoria"].Value != null &&
                    int.TryParse(row.Cells["Id_Categoria"].Value.ToString(), out int id) &&
                    id > max)
                {
                    max = id;
                }
            }
            return max + 1;
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            FrmEditarCategoria categoria = new FrmEditarCategoria
            {
                IdCategoria = 0,
                IdAsignado = ObtenerSiguienteId()
            };

            if (categoria.ShowDialog(FindForm()) == DialogResult.OK)
            {
                Llenar_Grid();
            }
        }

        private void AbrirEdicion(int posActual)
        {
            FrmEditarCategoria categoria = new FrmEditarCategoria
            {
                IdCategoria = int.Parse(DgCategorias.Rows[posActual].Cells["Id_Categoria"].Value.ToString()),
                Nombre = DgCategorias.Rows[posActual].Cells["StrCategoria"].Value?.ToString(),
                Descripcion = DgCategorias.Rows[posActual].Cells["StrDescripcion"].Value?.ToString()
            };

            if (categoria.ShowDialog(FindForm()) == DialogResult.OK)
            {
                Llenar_Grid();
            }
        }

        private void DgCategorias_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;
            string columna = DgCategorias.Columns[e.ColumnIndex].Name;
            int posActual = e.RowIndex;
            if (columna == "BtnBorrar")
            {
                if (MessageBox.Show("Seguro de borrar", "CONFIRMACION",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string id = DgCategorias.Rows[posActual].Cells["Id_Categoria"].Value.ToString();
                    string sentencia = $"delete from TBLCATEGORIA_PROD where IdCategoria = {id}";
                    string resultado = Acceso.EjecutarComando(sentencia);
                    if (resultado.Contains("REFERENCE"))
                        MessageBox.Show("No se puede eliminar: hay productos en esta categoría.");
                    else
                        MessageBox.Show(resultado);
                    Llenar_Grid();
                }
            }
            else if (columna == "BtnEditar")
            {
                AbrirEdicion(posActual);
            }
            DgCategorias.EndEdit();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            DgCategorias.Rows.Clear();
            string sentencia = "select IdCategoria, StrDescripcion from TBLCATEGORIA_PROD";
            if (TxtBuscarCategoria.Text != "")
                sentencia += $" where StrDescripcion like '%{TxtBuscarCategoria.Text}%'";
            dt = Acceso.EjecutarComandoDatos(sentencia);
            if (dt == null)
                return;
            foreach (DataRow row in dt.Rows)
            {
                DgCategorias.Rows.Add(
                    row["IdCategoria"],
                    row["StrDescripcion"],
                    row["StrDescripcion"]);
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
