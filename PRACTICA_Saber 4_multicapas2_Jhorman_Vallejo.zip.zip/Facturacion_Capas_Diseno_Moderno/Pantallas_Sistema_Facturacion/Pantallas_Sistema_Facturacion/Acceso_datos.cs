﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    internal class Acceso_datos
    {
        SqlConnection conexion;
        SqlCommand cmd;
        SqlDataReader LectorDatos = null;
        SqlDataAdapter da;
        DataTable dt;
        DataSet ds;

        public void AbrirBd()
        {
            try
            {
                conexion = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=[DBFACTURAS];Integrated Security=true;TrustServerCertificate=true;");
                conexion.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al abrir la base de datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public void CerrarBd()
        {
            try
            {
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cerrar la base de datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public string ValidarUsuario(string StrUsuario, string StrClave)
        {
            try
            {
                string strEmpleado = "";
                string sentencia = $"select e.strNombre, e.IdRolEmpleado from TBLSEGURIDAD s " +
                    $"JOIN TBLEMPLEADO e ON s.IdEmpleado = e.IdEmpleado " +
                    $"where StrUsuario = '{StrUsuario}' and StrClave = '{StrClave}'";

                AbrirBd();
                cmd = new SqlCommand();
                cmd.Connection = conexion;
                cmd.CommandText = sentencia;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 10;

                LectorDatos = cmd.ExecuteReader();

                while (LectorDatos.Read())
                {
                    strEmpleado = Convert.ToString(LectorDatos.GetValue(0));
                }

                if (LectorDatos != null)
                {
                    LectorDatos.Close();
                }

                return strEmpleado;
            }
            catch (Exception ex)
            {
                MessageBox.Show("FALLA LECTURA: " + ex.Message);
                return "";
            }
        }

        public string EjecutarComando(string sentencia)
        {
            string salida = "LOS DATOS SE ACTUALIZARON SATISFACTORIAMENTE!";
            try
            {
                int retornado;
                AbrirBd();
                cmd = new SqlCommand(sentencia, conexion);
                retornado = cmd.ExecuteNonQuery();
                CerrarBd();

                if (retornado > 0)
                    salida = "Los datos fueron Actualizados";
                else
                    salida = "Los datos no fueron Actualizados";
            }
            catch (Exception ex)
            {
                salida = "falló inserción: " + ex;
            }
            return salida;
        }

        public DataTable EjecutarComandoDatos(string sentencia)
        {
            try
            {
                AbrirBd();
                da = new SqlDataAdapter(sentencia, conexion);
                dt = new DataTable();
                da.Fill(dt);
                CerrarBd();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("FALLÓ OPERACIÓN: " + ex);
                return null;
            }
        }

        // Guía: llena combos. tabla = nombre de tabla, strCondicion = "" o un WHERE
        public DataTable cargarTabla(string tabla, string strCondicion)
        {
            try
            {
                AbrirBd();
                string Sql = "Select * from " + tabla + " " + strCondicion;
                da = new SqlDataAdapter(Sql, conexion);
                ds = new DataSet();
                da.Fill(ds, tabla);
                DataTable tablaDatos = ds.Tables[tabla];
                CerrarBd();
                return tablaDatos;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN LA CONSULTA: " + ex.ToString());
                return null;
            }
        }
    }
}
