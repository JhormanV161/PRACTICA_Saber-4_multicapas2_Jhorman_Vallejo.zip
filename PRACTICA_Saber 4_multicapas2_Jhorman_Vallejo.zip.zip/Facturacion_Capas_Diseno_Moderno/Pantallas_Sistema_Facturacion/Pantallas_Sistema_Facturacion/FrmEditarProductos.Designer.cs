namespace Pantallas_Sistema_Facturacion
{
    partial class FrmEditarProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TxtIdProducto = new System.Windows.Forms.TextBox();
            this.BtnSalir = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnActualizar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.TxtPrecio = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.TxtInventario = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.TxtNombre = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.CmbCategoria = new System.Windows.Forms.ComboBox();
            this.LblTitulo = new MaterialSkin.Controls.MaterialLabel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtIdProducto
            // 
            this.TxtIdProducto.Location = new System.Drawing.Point(47, 177);
            this.TxtIdProducto.Name = "TxtIdProducto";
            this.TxtIdProducto.Size = new System.Drawing.Size(40, 22);
            this.TxtIdProducto.TabIndex = 17;
            // 
            // BtnSalir
            // 
            this.BtnSalir.Depth = 0;
            this.BtnSalir.Location = new System.Drawing.Point(377, 450);
            this.BtnSalir.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Primary = true;
            this.BtnSalir.Size = new System.Drawing.Size(135, 28);
            this.BtnSalir.TabIndex = 16;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.Depth = 0;
            this.BtnActualizar.Location = new System.Drawing.Point(196, 450);
            this.BtnActualizar.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Primary = true;
            this.BtnActualizar.Size = new System.Drawing.Size(135, 28);
            this.BtnActualizar.TabIndex = 15;
            this.BtnActualizar.Text = "Actualizar";
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // TxtPrecio
            // 
            this.TxtPrecio.Depth = 0;
            this.TxtPrecio.Hint = "Precio";
            this.TxtPrecio.Location = new System.Drawing.Point(71, 254);
            this.TxtPrecio.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtPrecio.Name = "TxtPrecio";
            this.TxtPrecio.PasswordChar = '\0';
            this.TxtPrecio.SelectedText = "";
            this.TxtPrecio.SelectionLength = 0;
            this.TxtPrecio.SelectionStart = 0;
            this.TxtPrecio.Size = new System.Drawing.Size(492, 28);
            this.TxtPrecio.TabIndex = 14;
            this.TxtPrecio.UseSystemPasswordChar = false;
            // 
            // TxtInventario
            // 
            this.TxtInventario.Depth = 0;
            this.TxtInventario.Hint = "Inventario";
            this.TxtInventario.Location = new System.Drawing.Point(71, 288);
            this.TxtInventario.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtInventario.Name = "TxtInventario";
            this.TxtInventario.PasswordChar = '\0';
            this.TxtInventario.SelectedText = "";
            this.TxtInventario.SelectionLength = 0;
            this.TxtInventario.SelectionStart = 0;
            this.TxtInventario.Size = new System.Drawing.Size(492, 28);
            this.TxtInventario.TabIndex = 11;
            this.TxtInventario.UseSystemPasswordChar = false;
            // 
            // TxtNombre
            // 
            this.TxtNombre.Depth = 0;
            this.TxtNombre.Hint = "Nombre Producto";
            this.TxtNombre.Location = new System.Drawing.Point(71, 220);
            this.TxtNombre.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.PasswordChar = '\0';
            this.TxtNombre.SelectedText = "";
            this.TxtNombre.SelectionLength = 0;
            this.TxtNombre.SelectionStart = 0;
            this.TxtNombre.Size = new System.Drawing.Size(492, 28);
            this.TxtNombre.TabIndex = 10;
            this.TxtNombre.UseSystemPasswordChar = false;
            // 
            // CmbCategoria
            // 
            this.CmbCategoria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCategoria.FormattingEnabled = true;
            this.CmbCategoria.Location = new System.Drawing.Point(71, 322);
            this.CmbCategoria.Name = "CmbCategoria";
            this.CmbCategoria.Size = new System.Drawing.Size(492, 24);
            this.CmbCategoria.TabIndex = 13;
            // 
            // LblTitulo
            // 
            this.LblTitulo.AutoSize = true;
            this.LblTitulo.Depth = 0;
            this.LblTitulo.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblTitulo.Location = new System.Drawing.Point(272, 46);
            this.LblTitulo.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(185, 24);
            this.LblTitulo.TabIndex = 9;
            this.LblTitulo.Text = "Actualizar Productos";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FrmEditarProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 561);
            this.Controls.Add(this.TxtIdProducto);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnActualizar);
            this.Controls.Add(this.TxtPrecio);
            this.Controls.Add(this.TxtInventario);
            this.Controls.Add(this.CmbCategoria);
            this.Controls.Add(this.TxtNombre);
            this.Controls.Add(this.LblTitulo);
            this.Name = "FrmEditarProductos";
            this.Text = "FrmEditarProductos";
            this.Load += new System.EventHandler(this.FrmEditarProductos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtIdProducto;
        private MaterialSkin.Controls.MaterialRaisedButton BtnSalir;
        private MaterialSkin.Controls.MaterialRaisedButton BtnActualizar;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtPrecio;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtInventario;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtNombre;
        private System.Windows.Forms.ComboBox CmbCategoria;
        private MaterialSkin.Controls.MaterialLabel LblTitulo;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}