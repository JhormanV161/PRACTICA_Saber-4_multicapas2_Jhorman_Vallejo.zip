using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmEditarCliente : Form
    {
        public int IdCliente { get; set; }
        public int IdAsignado { get; set; }

        DataTable dt = new DataTable();
        Cls_Clientes cliente = new Cls_Clientes();

        public FrmEditarCliente()
        {
            InitializeComponent();
        }

        private void FrmEditarCliente_Load(object sender, EventArgs e)
        {
            TxtIdCliente.ReadOnly = true;

            if (IdCliente == 0)
            {
                LblTitulo.Text = "INGRESO NUEVO CLIENTE";
                TxtIdCliente.Text = IdAsignado.ToString();
            }
            else
            {
                LblTitulo.Text = "MODIFICAR CLIENTE";
                TxtIdCliente.Text = IdCliente.ToString();
                Llenar_campos();
            }
        }

        private void Llenar_campos()
        {
            dt = cliente.Consulta_Cliente(IdCliente);
            if (dt == null || dt.Rows.Count == 0)
                return;

            DataRow row = dt.Rows[0];
            TxtNombre.Text = row["StrNombre"].ToString();
            TxtDocumento.Text = row["NumDocumento"].ToString();
            TxtDireccion.Text = row["StrDireccion"].ToString();
            TxtTelefono.Text = row["StrTelefono"].ToString();
            TxtEmail.Text = row["StrEmail"].ToString();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            bool valido = true;
            if (string.IsNullOrWhiteSpace(TxtNombre.Text))
            {
                errorProvider1.SetError(TxtNombre, "El nombre es obligatorio.");
                valido = false;
            }
            else if (TxtNombre.Text.Length > 55)
            {
                errorProvider1.SetError(TxtNombre, "Nombre inválido. Máximo 55 caracteres.");
                valido = false;
            }

            if (string.IsNullOrWhiteSpace(TxtDocumento.Text))
            {
                errorProvider1.SetError(TxtDocumento, "El documento es obligatorio.");
                valido = false;
            }
            else if (TxtDocumento.Text.Length > 10)
            {
                errorProvider1.SetError(TxtDocumento, "Documento inválido. Máximo 10 dígitos.");
                valido = false;
            }
            else
            {
                foreach (char c in TxtDocumento.Text)
                {
                    if (!char.IsDigit(c))
                    {
                        errorProvider1.SetError(TxtDocumento, "El documento solo puede tener números.");
                        valido = false;
                        break;
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(TxtDireccion.Text))
            {
                errorProvider1.SetError(TxtDireccion, "La dirección es obligatoria.");
                valido = false;
            }
            else if (TxtDireccion.Text.Length > 70)
            {
                errorProvider1.SetError(TxtDireccion, "Dirección inválida. Máximo 70 caracteres.");
                valido = false;
            }

            if (string.IsNullOrWhiteSpace(TxtTelefono.Text))
            {
                errorProvider1.SetError(TxtTelefono, "El teléfono es obligatorio.");
                valido = false;
            }
            else if (TxtTelefono.Text.Length != 10)
            {
                errorProvider1.SetError(TxtTelefono, "El teléfono debe tener 10 dígitos. Ejemplo: 3011234567 o 6041234567");
                valido = false;
            }
            else
            {
                foreach (char c in TxtTelefono.Text)
                {
                    if (!char.IsDigit(c))
                    {
                        errorProvider1.SetError(TxtTelefono, "El teléfono solo puede tener números.");
                        valido = false;
                        break;
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(TxtEmail.Text))
            {
                errorProvider1.SetError(TxtEmail, "El email es obligatorio.");
                valido = false;
            }
            else if (TxtEmail.Text.Length > 50)
            {
                errorProvider1.SetError(TxtEmail, "Correo inválido. Máximo 50 caracteres.");
                valido = false;
            }
            else if (!(TxtEmail.Text.Contains("@") && TxtEmail.Text.Contains(".")))
            {
                errorProvider1.SetError(TxtEmail, "Ingrese un correo válido. Ejemplo: nombre@gmail.com");
                valido = false;
            }

            if (!valido)
                return;

            cliente.C_IdCliente = IdCliente;
            cliente.C_StrNombre = TxtNombre.Text;
            cliente.C_NumDocumento = double.Parse(TxtDocumento.Text);
            cliente.C_StrDireccion = TxtDireccion.Text;
            cliente.C_StrTelefono = TxtTelefono.Text;
            cliente.C_StrEmail = TxtEmail.Text;
            cliente.C_StrUsuarioModifica = "Jhorman";

            MessageBox.Show(cliente.ActualizarCliente());
            DialogResult = DialogResult.OK;
            Close();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}