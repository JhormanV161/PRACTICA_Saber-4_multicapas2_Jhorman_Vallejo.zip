using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmListaClientes : Form
    {
        public FrmListaClientes()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable();
        Cls_Clientes cliente = new Cls_Clientes();

        private void Llenar_Grid()
        {
            DgClientes.Rows.Clear();
            dt = cliente.Consulta_Cliente();
            if (dt == null || dt.Rows.Count == 0)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgClientes.Rows.Add(
                    row["IdCliente"],
                    row["StrNombre"],
                    row["NumDocumento"],
                    row["StrTelefono"]);
            }
        }

        private void FrmListaClientes_Load(object sender, EventArgs e)
        {
            Llenar_Grid();
        }

        private int ObtenerSiguienteId()
        {
            int max = 0;
            foreach (DataGridViewRow row in DgClientes.Rows)
            {
                if (row.Cells["Id_Cliente"].Value != null &&
                    int.TryParse(row.Cells["Id_Cliente"].Value.ToString(), out int id) &&
                    id > max)
                {
                    max = id;
                }
            }
            return max + 1;
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            FrmEditarCliente frm = new FrmEditarCliente
            {
                IdCliente = 0,
                IdAsignado = ObtenerSiguienteId()
            };

            if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                Llenar_Grid();
        }

        private void DgClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            string columna = DgClientes.Columns[e.ColumnIndex].Name;
            int posActual = e.RowIndex;

            if (columna == "BtnBorrar")
            {
                if (MessageBox.Show("Seguro de borrar", "CONFIRMACION",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cliente.C_IdCliente = int.Parse(
                        DgClientes.Rows[posActual].Cells["Id_Cliente"].Value.ToString());
                    string resultado = cliente.EliminarCliente();

                    if (resultado.Contains("REFERENCE"))
                        MessageBox.Show("No se puede eliminar: este cliente tiene facturas asociadas.");
                    else
                        MessageBox.Show(resultado);

                    Llenar_Grid();
                }
            }
            else if (columna == "BtnEditar")
            {
                FrmEditarCliente frm = new FrmEditarCliente
                {
                    IdCliente = int.Parse(
                        DgClientes.Rows[posActual].Cells["Id_Cliente"].Value.ToString())
                };

                if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                    Llenar_Grid();
            }

            DgClientes.EndEdit();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            DgClientes.Rows.Clear();
            if (TxtBuscar.Text != "")
                dt = cliente.Filtrar_Cliente(TxtBuscar.Text);
            else
                dt = cliente.Consulta_Cliente();

            if (dt == null)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgClientes.Rows.Add(
                    row["IdCliente"],
                    row["StrNombre"],
                    row["NumDocumento"],
                    row["StrTelefono"]);
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}