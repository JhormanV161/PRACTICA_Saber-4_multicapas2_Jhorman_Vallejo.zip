using System;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmAyuda : Form
    {
        private const string UrlAyuda = "https://learn.microsoft.com/es-es/";

        public FrmAyuda()
        {
            InitializeComponent();
            WbAyuda.ScriptErrorsSuppressed = true;
        }

        private void FrmAyuda_Load(object sender, EventArgs e)
        {
            if (WbAyuda.Url == null)
                WbAyuda.Navigate(UrlAyuda);
        }
    }
}
