using System;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;

namespace Pantallas_Sistema_Facturacion
{
    internal static class BrowserEmulationHelper
    {
        private const int Ie11Emulation = 11001;

        public static void EnableIe11Emulation()
        {
            try
            {
                string exeName = Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(
                    @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION",
                    true))
                {
                    if (key != null)
                        key.SetValue(exeName, Ie11Emulation, RegistryValueKind.DWord);
                }
            }
            catch
            {
                // Si falla el registro, el WebBrowser sigue funcionando en modo compatibilidad.
            }
        }
    }
}
