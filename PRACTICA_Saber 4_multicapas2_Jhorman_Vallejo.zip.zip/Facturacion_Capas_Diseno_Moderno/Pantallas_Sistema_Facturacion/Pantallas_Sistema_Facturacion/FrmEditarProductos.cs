using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmEditarProductos : Form
    {
        public int IdProducto { get; set; }
        public int IdAsignado { get; set; }

        DataTable dt = new DataTable();
        Cls_Productos producto = new Cls_Productos();
        string codigo = "000";
        string detalle = "ninguno";
        string foto = "ninguna";

        public FrmEditarProductos()
        {
            InitializeComponent();
        }

        private void FrmEditarProductos_Load(object sender, EventArgs e)
        {
            Llenar_combo();
            TxtIdProducto.ReadOnly = true;

            if (IdProducto == 0)
            {
                LblTitulo.Text = "INGRESO NUEVO PRODUCTO";
                TxtIdProducto.Text = IdAsignado.ToString();
                if (CmbCategoria.Items.Count > 0)
                    CmbCategoria.SelectedIndex = 0;
            }
            else
            {
                LblTitulo.Text = "MODIFICAR PRODUCTO";
                TxtIdProducto.Text = IdProducto.ToString();
                Llenar_campos();
            }
        }

        private void Llenar_combo()
        {
            CmbCategoria.DisplayMember = "StrDescripcion";
            CmbCategoria.ValueMember = "IdCategoria";
            CmbCategoria.DataSource = producto.ConsultarCategoria();
        }

        private void Llenar_campos()
        {
            dt = producto.Consulta_Producto(IdProducto);
            if (dt == null || dt.Rows.Count == 0)
                return;

            DataRow row = dt.Rows[0];
            TxtNombre.Text = row["StrNombre"].ToString();
            TxtPrecio.Text = row["NumPrecioVenta"].ToString();
            TxtInventario.Text = row["NumStock"].ToString();
            CmbCategoria.SelectedValue = Convert.ToInt32(row["IdCategoria"]);
            codigo = row["StrCodigo"].ToString();
            detalle = row["StrDetalle"].ToString();
            foto = row["strFoto"].ToString();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            bool valido = true;

            if (string.IsNullOrWhiteSpace(TxtNombre.Text))
            {
                errorProvider1.SetError(TxtNombre, "El nombre es obligatorio.");
                valido = false;
            }
            if (string.IsNullOrWhiteSpace(TxtPrecio.Text))
            {
                errorProvider1.SetError(TxtPrecio, "El precio es obligatorio.");
                valido = false;
            }
            if (CmbCategoria.SelectedValue == null || CmbCategoria.SelectedValue is DataRowView)
            {
                errorProvider1.SetError(CmbCategoria, "La categoria es obligatoria.");
                valido = false;
            }
            if (string.IsNullOrWhiteSpace(TxtInventario.Text))
            {
                errorProvider1.SetError(TxtInventario, "El inventario es obligatorio.");
                valido = false;
            }
            if (!valido)
                return;

            producto.C_IdProducto = IdProducto;
            producto.C_StrNombre = TxtNombre.Text;
            producto.C_StrCodigo = codigo;
            producto.C_NumPrecioCompra = double.Parse(TxtPrecio.Text);
            producto.C_NumPrecioVenta = double.Parse(TxtPrecio.Text);
            producto.C_IdCategoria = Convert.ToInt32(CmbCategoria.SelectedValue);
            producto.C_StrDetalle = detalle;
            producto.C_strFoto = foto;
            producto.C_NumStock = int.Parse(TxtInventario.Text);
            producto.C_StrUsuarioModifica = "Jhorman";

            MessageBox.Show(producto.ActualizarProducto());
            DialogResult = DialogResult.OK;
            Close();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}