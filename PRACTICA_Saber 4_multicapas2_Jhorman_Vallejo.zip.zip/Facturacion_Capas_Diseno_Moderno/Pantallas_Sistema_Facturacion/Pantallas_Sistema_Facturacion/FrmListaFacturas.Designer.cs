namespace Pantallas_Sistema_Facturacion
{
    partial class FrmListaFacturas
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.DgFacturas = new System.Windows.Forms.DataGridView();
            this.BtnSalir = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnNuevo = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnBuscar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.TxtBuscarFactura = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.LblTitulo = new MaterialSkin.Controls.MaterialLabel();
            this.Id_Factura = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StrCliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StrFecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StrTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnEditar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.BtnBorrar = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DgFacturas)).BeginInit();
            this.SuspendLayout();
            // 
            // DgFacturas
            // 
            this.DgFacturas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgFacturas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgFacturas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id_Factura,
            this.StrCliente,
            this.StrFecha,
            this.StrTotal,
            this.BtnEditar,
            this.BtnBorrar});
            this.DgFacturas.Location = new System.Drawing.Point(18, 87);
            this.DgFacturas.Name = "DgFacturas";
            this.DgFacturas.RowHeadersWidth = 51;
            this.DgFacturas.RowTemplate.Height = 24;
            this.DgFacturas.Size = new System.Drawing.Size(850, 440);
            this.DgFacturas.TabIndex = 12;
            this.DgFacturas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgFacturas_CellClick);
            // 
            // BtnSalir
            // 
            this.BtnSalir.Depth = 0;
            this.BtnSalir.Location = new System.Drawing.Point(793, 533);
            this.BtnSalir.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Primary = true;
            this.BtnSalir.Size = new System.Drawing.Size(75, 23);
            this.BtnSalir.TabIndex = 11;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // BtnNuevo
            // 
            this.BtnNuevo.Depth = 0;
            this.BtnNuevo.Location = new System.Drawing.Point(793, 58);
            this.BtnNuevo.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnNuevo.Name = "BtnNuevo";
            this.BtnNuevo.Primary = true;
            this.BtnNuevo.Size = new System.Drawing.Size(75, 23);
            this.BtnNuevo.TabIndex = 10;
            this.BtnNuevo.Text = "Nuevo";
            this.BtnNuevo.UseVisualStyleBackColor = true;
            this.BtnNuevo.Click += new System.EventHandler(this.BtnNuevo_Click);
            // 
            // BtnBuscar
            // 
            this.BtnBuscar.Depth = 0;
            this.BtnBuscar.Location = new System.Drawing.Point(712, 58);
            this.BtnBuscar.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnBuscar.Name = "BtnBuscar";
            this.BtnBuscar.Primary = true;
            this.BtnBuscar.Size = new System.Drawing.Size(75, 23);
            this.BtnBuscar.TabIndex = 9;
            this.BtnBuscar.Text = "Buscar";
            this.BtnBuscar.UseVisualStyleBackColor = true;
            this.BtnBuscar.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // TxtBuscarFactura
            // 
            this.TxtBuscarFactura.Depth = 0;
            this.TxtBuscarFactura.Hint = "Buscar Factura";
            this.TxtBuscarFactura.Location = new System.Drawing.Point(18, 53);
            this.TxtBuscarFactura.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtBuscarFactura.Name = "TxtBuscarFactura";
            this.TxtBuscarFactura.PasswordChar = '\0';
            this.TxtBuscarFactura.SelectedText = "";
            this.TxtBuscarFactura.SelectionStart = 0;
            this.TxtBuscarFactura.Size = new System.Drawing.Size(688, 28);
            this.TxtBuscarFactura.TabIndex = 8;
            this.TxtBuscarFactura.UseSystemPasswordChar = false;
            // 
            // LblTitulo
            // 
            this.LblTitulo.AutoSize = true;
            this.LblTitulo.Depth = 0;
            this.LblTitulo.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblTitulo.Location = new System.Drawing.Point(280, 9);
            this.LblTitulo.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(254, 24);
            this.LblTitulo.TabIndex = 7;
            this.LblTitulo.Text = "ADMINISTRACION DE FACTURAS";
            // 
            // Id_Factura
            // 
            this.Id_Factura.HeaderText = "ID";
            this.Id_Factura.MinimumWidth = 6;
            this.Id_Factura.Name = "Id_Factura";
            this.Id_Factura.Width = 80;
            // 
            // StrCliente
            // 
            this.StrCliente.HeaderText = "CLIENTE";
            this.StrCliente.MinimumWidth = 6;
            this.StrCliente.Name = "StrCliente";
            this.StrCliente.Width = 220;
            // 
            // StrFecha
            // 
            this.StrFecha.HeaderText = "FECHA";
            this.StrFecha.MinimumWidth = 6;
            this.StrFecha.Name = "StrFecha";
            this.StrFecha.Width = 150;
            // 
            // StrTotal
            // 
            this.StrTotal.HeaderText = "TOTAL";
            this.StrTotal.MinimumWidth = 6;
            this.StrTotal.Name = "StrTotal";
            this.StrTotal.Width = 150;
            // 
            // BtnEditar
            // 
            this.BtnEditar.HeaderText = "EDITAR";
            this.BtnEditar.MinimumWidth = 6;
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Text = "EDITAR";
            this.BtnEditar.UseColumnTextForButtonValue = true;
            this.BtnEditar.Width = 80;
            // 
            // BtnBorrar
            // 
            this.BtnBorrar.HeaderText = "BORRAR";
            this.BtnBorrar.MinimumWidth = 6;
            this.BtnBorrar.Name = "BtnBorrar";
            this.BtnBorrar.Text = "BORRAR";
            this.BtnBorrar.UseColumnTextForButtonValue = true;
            this.BtnBorrar.Width = 80;
            // 
            // FrmListaFacturas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(880, 580);
            this.Controls.Add(this.DgFacturas);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnNuevo);
            this.Controls.Add(this.BtnBuscar);
            this.Controls.Add(this.TxtBuscarFactura);
            this.Controls.Add(this.LblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmListaFacturas";
            this.Text = "LISTA DE FACTURAS";
            this.Load += new System.EventHandler(this.FrmListaFacturas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DgFacturas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView DgFacturas;
        private MaterialSkin.Controls.MaterialRaisedButton BtnSalir;
        private MaterialSkin.Controls.MaterialRaisedButton BtnNuevo;
        private MaterialSkin.Controls.MaterialRaisedButton BtnBuscar;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtBuscarFactura;
        private MaterialSkin.Controls.MaterialLabel LblTitulo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_Factura;
        private System.Windows.Forms.DataGridViewTextBoxColumn StrCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn StrFecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn StrTotal;
        private System.Windows.Forms.DataGridViewButtonColumn BtnEditar;
        private System.Windows.Forms.DataGridViewButtonColumn BtnBorrar;
    }
}
