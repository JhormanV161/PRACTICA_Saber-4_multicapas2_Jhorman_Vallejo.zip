namespace Pantallas_Sistema_Facturacion
{
    partial class FrmListaRoles
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.DgRoles = new System.Windows.Forms.DataGridView();
            this.BtnSalir = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnNuevo = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnBuscar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.TxtBuscarRol = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.LblTitulo = new MaterialSkin.Controls.MaterialLabel();
            this.Id_Rol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StrRol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StrDescripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnEditar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.BtnBorrar = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DgRoles)).BeginInit();
            this.SuspendLayout();
            // 
            // DgRoles
            // 
            this.DgRoles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgRoles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgRoles.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id_Rol,
            this.StrRol,
            this.StrDescripcion,
            this.BtnEditar,
            this.BtnBorrar});
            this.DgRoles.Location = new System.Drawing.Point(18, 87);
            this.DgRoles.Name = "DgRoles";
            this.DgRoles.RowHeadersWidth = 51;
            this.DgRoles.RowTemplate.Height = 24;
            this.DgRoles.Size = new System.Drawing.Size(850, 440);
            this.DgRoles.TabIndex = 12;
            this.DgRoles.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgRoles_CellClick);
            // 
            // BtnSalir
            // 
            this.BtnSalir.Depth = 0;
            this.BtnSalir.Location = new System.Drawing.Point(793, 533);
            this.BtnSalir.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Primary = true;
            this.BtnSalir.Size = new System.Drawing.Size(75, 23);
            this.BtnSalir.TabIndex = 11;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // BtnNuevo
            // 
            this.BtnNuevo.Depth = 0;
            this.BtnNuevo.Location = new System.Drawing.Point(793, 58);
            this.BtnNuevo.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnNuevo.Name = "BtnNuevo";
            this.BtnNuevo.Primary = true;
            this.BtnNuevo.Size = new System.Drawing.Size(75, 23);
            this.BtnNuevo.TabIndex = 10;
            this.BtnNuevo.Text = "Nuevo";
            this.BtnNuevo.UseVisualStyleBackColor = true;
            this.BtnNuevo.Click += new System.EventHandler(this.BtnNuevo_Click);
            // 
            // BtnBuscar
            // 
            this.BtnBuscar.Depth = 0;
            this.BtnBuscar.Location = new System.Drawing.Point(712, 58);
            this.BtnBuscar.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnBuscar.Name = "BtnBuscar";
            this.BtnBuscar.Primary = true;
            this.BtnBuscar.Size = new System.Drawing.Size(75, 23);
            this.BtnBuscar.TabIndex = 9;
            this.BtnBuscar.Text = "Buscar";
            this.BtnBuscar.UseVisualStyleBackColor = true;
            this.BtnBuscar.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // TxtBuscarRol
            // 
            this.TxtBuscarRol.Depth = 0;
            this.TxtBuscarRol.Hint = "Buscar Rol";
            this.TxtBuscarRol.Location = new System.Drawing.Point(18, 53);
            this.TxtBuscarRol.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtBuscarRol.Name = "TxtBuscarRol";
            this.TxtBuscarRol.PasswordChar = '\0';
            this.TxtBuscarRol.SelectedText = "";
            this.TxtBuscarRol.SelectionLength = 0;
            this.TxtBuscarRol.SelectionStart = 0;
            this.TxtBuscarRol.Size = new System.Drawing.Size(688, 28);
            this.TxtBuscarRol.TabIndex = 8;
            this.TxtBuscarRol.UseSystemPasswordChar = false;
            // 
            // LblTitulo
            // 
            this.LblTitulo.AutoSize = true;
            this.LblTitulo.Depth = 0;
            this.LblTitulo.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblTitulo.Location = new System.Drawing.Point(280, 9);
            this.LblTitulo.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(254, 24);
            this.LblTitulo.TabIndex = 7;
            this.LblTitulo.Text = "ADMINISTRACION DE ROLES";
            // 
            // Id_Rol
            // 
            this.Id_Rol.HeaderText = "ID";
            this.Id_Rol.MinimumWidth = 6;
            this.Id_Rol.Name = "Id_Rol";
            this.Id_Rol.Width = 80;
            // 
            // StrRol
            // 
            this.StrRol.HeaderText = "ROL";
            this.StrRol.MinimumWidth = 6;
            this.StrRol.Name = "StrRol";
            this.StrRol.Width = 250;
            // 
            // StrDescripcion
            // 
            this.StrDescripcion.HeaderText = "DESCRIPCION";
            this.StrDescripcion.MinimumWidth = 6;
            this.StrDescripcion.Name = "StrDescripcion";
            this.StrDescripcion.Width = 300;
            // 
            // BtnEditar
            // 
            this.BtnEditar.HeaderText = "EDITAR";
            this.BtnEditar.MinimumWidth = 6;
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Text = "EDITAR";
            this.BtnEditar.UseColumnTextForButtonValue = true;
            this.BtnEditar.Width = 80;
            // 
            // BtnBorrar
            // 
            this.BtnBorrar.HeaderText = "BORRAR";
            this.BtnBorrar.MinimumWidth = 6;
            this.BtnBorrar.Name = "BtnBorrar";
            this.BtnBorrar.Text = "BORRAR";
            this.BtnBorrar.UseColumnTextForButtonValue = true;
            this.BtnBorrar.Width = 80;
            // 
            // FrmListaRoles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(880, 580);
            this.Controls.Add(this.DgRoles);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnNuevo);
            this.Controls.Add(this.BtnBuscar);
            this.Controls.Add(this.TxtBuscarRol);
            this.Controls.Add(this.LblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmListaRoles";
            this.Text = "LISTA DE ROLES";
            this.Load += new System.EventHandler(this.FrmListaRoles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DgRoles)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView DgRoles;
        private MaterialSkin.Controls.MaterialRaisedButton BtnSalir;
        private MaterialSkin.Controls.MaterialRaisedButton BtnNuevo;
        private MaterialSkin.Controls.MaterialRaisedButton BtnBuscar;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtBuscarRol;
        private MaterialSkin.Controls.MaterialLabel LblTitulo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_Rol;
        private System.Windows.Forms.DataGridViewTextBoxColumn StrRol;
        private System.Windows.Forms.DataGridViewTextBoxColumn StrDescripcion;
        private System.Windows.Forms.DataGridViewButtonColumn BtnEditar;
        private System.Windows.Forms.DataGridViewButtonColumn BtnBorrar;
    }
}
