namespace Pantallas_Sistema_Facturacion
{
    partial class FrmEditarRoles
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LblTitulo = new System.Windows.Forms.Label();
            this.LblNombreRol = new System.Windows.Forms.Label();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.LblDescripcion = new System.Windows.Forms.Label();
            this.TxtDescripcion = new System.Windows.Forms.TextBox();
            this.BtnActualizar = new System.Windows.Forms.Button();
            this.BtnSalir = new System.Windows.Forms.Button();
            this.TxtIdRol = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            this.LblTitulo.Location = new System.Drawing.Point(300, 20);
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(280, 28);
            this.LblTitulo.TabIndex = 0;
            this.LblTitulo.Text = "ROL DE EMPLEADOS";
            this.LblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LblNombreRol.Location = new System.Drawing.Point(40, 70);
            this.LblNombreRol.Name = "LblNombreRol";
            this.LblNombreRol.Size = new System.Drawing.Size(120, 20);
            this.LblNombreRol.TabIndex = 1;
            this.LblNombreRol.Text = "Nombre Rol";
            this.TxtNombre.Location = new System.Drawing.Point(40, 93);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.Size = new System.Drawing.Size(800, 22);
            this.TxtNombre.TabIndex = 2;
            this.LblDescripcion.Location = new System.Drawing.Point(40, 130);
            this.LblDescripcion.Name = "LblDescripcion";
            this.LblDescripcion.Size = new System.Drawing.Size(200, 20);
            this.LblDescripcion.TabIndex = 3;
            this.LblDescripcion.Text = "Descripcion detallada Rol";
            this.TxtDescripcion.Location = new System.Drawing.Point(40, 153);
            this.TxtDescripcion.Multiline = true;
            this.TxtDescripcion.Name = "TxtDescripcion";
            this.TxtDescripcion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtDescripcion.Size = new System.Drawing.Size(800, 320);
            this.TxtDescripcion.TabIndex = 4;
            this.BtnActualizar.Location = new System.Drawing.Point(280, 510);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(180, 40);
            this.BtnActualizar.TabIndex = 5;
            this.BtnActualizar.Text = "ACTUALIZAR";
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            this.BtnSalir.Location = new System.Drawing.Point(480, 510);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(180, 40);
            this.BtnSalir.TabIndex = 6;
            this.BtnSalir.Text = "SALIR";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            this.TxtIdRol.Location = new System.Drawing.Point(40, 20);
            this.TxtIdRol.Name = "TxtIdRol";
            this.TxtIdRol.ReadOnly = true;
            this.TxtIdRol.Size = new System.Drawing.Size(40, 22);
            this.TxtIdRol.TabIndex = 7;
            this.TxtIdRol.Visible = false;
            this.errorProvider1.ContainerControl = this;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(880, 580);
            this.Controls.Add(this.TxtIdRol);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnActualizar);
            this.Controls.Add(this.TxtDescripcion);
            this.Controls.Add(this.LblDescripcion);
            this.Controls.Add(this.TxtNombre);
            this.Controls.Add(this.LblNombreRol);
            this.Controls.Add(this.LblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmEditarRoles";
            this.Text = "frmRolEmpleados";
            this.Load += new System.EventHandler(this.FrmEditarRoles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label LblTitulo;
        private System.Windows.Forms.Label LblNombreRol;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.Label LblDescripcion;
        private System.Windows.Forms.TextBox TxtDescripcion;
        private System.Windows.Forms.Button BtnActualizar;
        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.TextBox TxtIdRol;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}
