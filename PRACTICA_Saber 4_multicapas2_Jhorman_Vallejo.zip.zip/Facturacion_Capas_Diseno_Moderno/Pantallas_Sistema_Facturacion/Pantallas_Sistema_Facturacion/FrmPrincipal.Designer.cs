namespace Pantallas_Sistema_Facturacion
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabOpcionesMenu = new MaterialSkin.Controls.MaterialTabSelector();
            this.TbpMenu = new MaterialSkin.Controls.MaterialTabControl();
            this.Principal = new System.Windows.Forms.TabPage();
            this.BtnSalir = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Tablas = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.BtnCategorias = new System.Windows.Forms.Button();
            this.BtnClientes = new System.Windows.Forms.Button();
            this.BtnProductos = new System.Windows.Forms.Button();
            this.Facturacion = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.BtnFacturas = new System.Windows.Forms.Button();
            this.BtnInformes = new System.Windows.Forms.Button();
            this.Seguridad = new System.Windows.Forms.TabPage();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.BtnSeguridad = new System.Windows.Forms.Button();
            this.BtnEmpleados = new System.Windows.Forms.Button();
            this.BtnRoles = new System.Windows.Forms.Button();
            this.Ayuda = new System.Windows.Forms.TabPage();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.BtnAyuda = new System.Windows.Forms.Button();
            this.BtnAcercaDe = new System.Windows.Forms.Button();
            this.PnlMenu = new System.Windows.Forms.Panel();
            this.PnlPrincipal = new System.Windows.Forms.Panel();
            this.PnlContenedor = new System.Windows.Forms.Panel();
            this.TbpMenu.SuspendLayout();
            this.Principal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Tablas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.Facturacion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.Seguridad.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.Ayuda.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.PnlMenu.SuspendLayout();
            this.PnlPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabOpcionesMenu
            // 
            this.TabOpcionesMenu.BaseTabControl = this.TbpMenu;
            this.TabOpcionesMenu.Depth = 0;
            this.TabOpcionesMenu.Location = new System.Drawing.Point(300, 34);
            this.TabOpcionesMenu.MouseState = MaterialSkin.MouseState.HOVER;
            this.TabOpcionesMenu.Name = "TabOpcionesMenu";
            this.TabOpcionesMenu.Size = new System.Drawing.Size(853, 23);
            this.TabOpcionesMenu.TabIndex = 1;
            // 
            // TbpMenu
            // 
            this.TbpMenu.Controls.Add(this.Principal);
            this.TbpMenu.Controls.Add(this.Tablas);
            this.TbpMenu.Controls.Add(this.Facturacion);
            this.TbpMenu.Controls.Add(this.Seguridad);
            this.TbpMenu.Controls.Add(this.Ayuda);
            this.TbpMenu.Depth = 0;
            this.TbpMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbpMenu.Location = new System.Drawing.Point(0, 0);
            this.TbpMenu.MouseState = MaterialSkin.MouseState.HOVER;
            this.TbpMenu.Name = "TbpMenu";
            this.TbpMenu.SelectedIndex = 0;
            this.TbpMenu.Size = new System.Drawing.Size(250, 588);
            this.TbpMenu.TabIndex = 0;
            // 
            // Principal
            // 
            this.Principal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(52)))), ((int)(((byte)(59)))));
            this.Principal.Controls.Add(this.BtnSalir);
            this.Principal.Controls.Add(this.pictureBox1);
            this.Principal.Location = new System.Drawing.Point(4, 25);
            this.Principal.Name = "Principal";
            this.Principal.Padding = new System.Windows.Forms.Padding(3);
            this.Principal.Size = new System.Drawing.Size(242, 559);
            this.Principal.TabIndex = 0;
            this.Principal.Text = "Principal";
            // 
            // BtnSalir
            // 
            this.BtnSalir.FlatAppearance.BorderSize = 0;
            this.BtnSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSalir.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnSalir.ForeColor = System.Drawing.Color.White;
            this.BtnSalir.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.exit__1_;
            this.BtnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSalir.Location = new System.Drawing.Point(-4, 329);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(250, 53);
            this.BtnSalir.TabIndex = 2;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.logo__2_;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(240, 133);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Tablas
            // 
            this.Tablas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(52)))), ((int)(((byte)(59)))));
            this.Tablas.Controls.Add(this.pictureBox2);
            this.Tablas.Controls.Add(this.BtnCategorias);
            this.Tablas.Controls.Add(this.BtnClientes);
            this.Tablas.Controls.Add(this.BtnProductos);
            this.Tablas.Location = new System.Drawing.Point(4, 25);
            this.Tablas.Name = "Tablas";
            this.Tablas.Padding = new System.Windows.Forms.Padding(3);
            this.Tablas.Size = new System.Drawing.Size(242, 559);
            this.Tablas.TabIndex = 1;
            this.Tablas.Text = "Admin. Tablas";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.logo__2_;
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(240, 133);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // BtnCategorias
            // 
            this.BtnCategorias.FlatAppearance.BorderSize = 0;
            this.BtnCategorias.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnCategorias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCategorias.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnCategorias.ForeColor = System.Drawing.Color.White;
            this.BtnCategorias.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.categoria;
            this.BtnCategorias.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCategorias.Location = new System.Drawing.Point(-1, 385);
            this.BtnCategorias.Name = "BtnCategorias";
            this.BtnCategorias.Size = new System.Drawing.Size(247, 53);
            this.BtnCategorias.TabIndex = 6;
            this.BtnCategorias.Text = "      Categorias";
            this.BtnCategorias.UseVisualStyleBackColor = true;
            this.BtnCategorias.Click += new System.EventHandler(this.BtnCategorias_Click);
            // 
            // BtnClientes
            // 
            this.BtnClientes.FlatAppearance.BorderSize = 0;
            this.BtnClientes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClientes.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnClientes.ForeColor = System.Drawing.Color.White;
            this.BtnClientes.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.clientes;
            this.BtnClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnClientes.Location = new System.Drawing.Point(-1, 267);
            this.BtnClientes.Name = "BtnClientes";
            this.BtnClientes.Size = new System.Drawing.Size(247, 53);
            this.BtnClientes.TabIndex = 5;
            this.BtnClientes.Text = "Clientes";
            this.BtnClientes.UseVisualStyleBackColor = true;
            this.BtnClientes.Click += new System.EventHandler(this.BtnClientes_Click);
            // 
            // BtnProductos
            // 
            this.BtnProductos.FlatAppearance.BorderSize = 0;
            this.BtnProductos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnProductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnProductos.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnProductos.ForeColor = System.Drawing.Color.White;
            this.BtnProductos.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.Productos;
            this.BtnProductos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnProductos.Location = new System.Drawing.Point(-1, 326);
            this.BtnProductos.Name = "BtnProductos";
            this.BtnProductos.Size = new System.Drawing.Size(247, 53);
            this.BtnProductos.TabIndex = 4;
            this.BtnProductos.Text = "   Productos";
            this.BtnProductos.UseVisualStyleBackColor = true;
            this.BtnProductos.Click += new System.EventHandler(this.BtnProductos_Click);
            // 
            // Facturacion
            // 
            this.Facturacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(52)))), ((int)(((byte)(59)))));
            this.Facturacion.Controls.Add(this.pictureBox3);
            this.Facturacion.Controls.Add(this.BtnFacturas);
            this.Facturacion.Controls.Add(this.BtnInformes);
            this.Facturacion.Location = new System.Drawing.Point(4, 25);
            this.Facturacion.Name = "Facturacion";
            this.Facturacion.Size = new System.Drawing.Size(242, 559);
            this.Facturacion.TabIndex = 2;
            this.Facturacion.Text = "Facturacion";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.logo__2_;
            this.pictureBox3.Location = new System.Drawing.Point(3, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(240, 133);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // BtnFacturas
            // 
            this.BtnFacturas.FlatAppearance.BorderSize = 0;
            this.BtnFacturas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnFacturas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFacturas.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnFacturas.ForeColor = System.Drawing.Color.White;
            this.BtnFacturas.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.facturas;
            this.BtnFacturas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFacturas.Location = new System.Drawing.Point(-1, 267);
            this.BtnFacturas.Name = "BtnFacturas";
            this.BtnFacturas.Size = new System.Drawing.Size(247, 53);
            this.BtnFacturas.TabIndex = 9;
            this.BtnFacturas.Text = "Facturas";
            this.BtnFacturas.UseVisualStyleBackColor = true;
            this.BtnFacturas.Click += new System.EventHandler(this.BtnFacturas_Click);
            // 
            // BtnInformes
            // 
            this.BtnInformes.FlatAppearance.BorderSize = 0;
            this.BtnInformes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnInformes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnInformes.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnInformes.ForeColor = System.Drawing.Color.White;
            this.BtnInformes.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.documentation;
            this.BtnInformes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnInformes.Location = new System.Drawing.Point(-1, 326);
            this.BtnInformes.Name = "BtnInformes";
            this.BtnInformes.Size = new System.Drawing.Size(247, 53);
            this.BtnInformes.TabIndex = 8;
            this.BtnInformes.Text = "Informes";
            this.BtnInformes.UseVisualStyleBackColor = true;
            this.BtnInformes.Click += new System.EventHandler(this.BtnInformes_Click);
            // 
            // Seguridad
            // 
            this.Seguridad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(52)))), ((int)(((byte)(59)))));
            this.Seguridad.Controls.Add(this.pictureBox4);
            this.Seguridad.Controls.Add(this.BtnSeguridad);
            this.Seguridad.Controls.Add(this.BtnEmpleados);
            this.Seguridad.Controls.Add(this.BtnRoles);
            this.Seguridad.Location = new System.Drawing.Point(4, 25);
            this.Seguridad.Name = "Seguridad";
            this.Seguridad.Size = new System.Drawing.Size(242, 559);
            this.Seguridad.TabIndex = 3;
            this.Seguridad.Text = "Seguridad";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.logo__2_;
            this.pictureBox4.Location = new System.Drawing.Point(3, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(240, 133);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // BtnSeguridad
            // 
            this.BtnSeguridad.FlatAppearance.BorderSize = 0;
            this.BtnSeguridad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnSeguridad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSeguridad.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnSeguridad.ForeColor = System.Drawing.Color.White;
            this.BtnSeguridad.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.seguridad;
            this.BtnSeguridad.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSeguridad.Location = new System.Drawing.Point(-1, 385);
            this.BtnSeguridad.Name = "BtnSeguridad";
            this.BtnSeguridad.Size = new System.Drawing.Size(244, 53);
            this.BtnSeguridad.TabIndex = 10;
            this.BtnSeguridad.Text = "     Seguridad";
            this.BtnSeguridad.UseVisualStyleBackColor = true;
            this.BtnSeguridad.Click += new System.EventHandler(this.BtnSeguridad_Click);
            // 
            // BtnEmpleados
            // 
            this.BtnEmpleados.FlatAppearance.BorderSize = 0;
            this.BtnEmpleados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnEmpleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEmpleados.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnEmpleados.ForeColor = System.Drawing.Color.White;
            this.BtnEmpleados.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.empleados;
            this.BtnEmpleados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEmpleados.Location = new System.Drawing.Point(-1, 267);
            this.BtnEmpleados.Name = "BtnEmpleados";
            this.BtnEmpleados.Size = new System.Drawing.Size(244, 53);
            this.BtnEmpleados.TabIndex = 9;
            this.BtnEmpleados.Text = "     Empleados";
            this.BtnEmpleados.UseVisualStyleBackColor = true;
            this.BtnEmpleados.Click += new System.EventHandler(this.BtnEmpleados_Click);
            // 
            // BtnRoles
            // 
            this.BtnRoles.FlatAppearance.BorderSize = 0;
            this.BtnRoles.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnRoles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRoles.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnRoles.ForeColor = System.Drawing.Color.White;
            this.BtnRoles.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.roles;
            this.BtnRoles.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnRoles.Location = new System.Drawing.Point(-1, 326);
            this.BtnRoles.Name = "BtnRoles";
            this.BtnRoles.Size = new System.Drawing.Size(244, 53);
            this.BtnRoles.TabIndex = 8;
            this.BtnRoles.Text = "   Roles";
            this.BtnRoles.UseVisualStyleBackColor = true;
            this.BtnRoles.Click += new System.EventHandler(this.BtnRoles_Click);
            // 
            // Ayuda
            // 
            this.Ayuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(52)))), ((int)(((byte)(59)))));
            this.Ayuda.Controls.Add(this.pictureBox5);
            this.Ayuda.Controls.Add(this.BtnAyuda);
            this.Ayuda.Controls.Add(this.BtnAcercaDe);
            this.Ayuda.Location = new System.Drawing.Point(4, 25);
            this.Ayuda.Name = "Ayuda";
            this.Ayuda.Size = new System.Drawing.Size(242, 559);
            this.Ayuda.TabIndex = 4;
            this.Ayuda.Text = "Ayuda";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.logo__2_;
            this.pictureBox5.Location = new System.Drawing.Point(3, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(240, 133);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // BtnAyuda
            // 
            this.BtnAyuda.FlatAppearance.BorderSize = 0;
            this.BtnAyuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnAyuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAyuda.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnAyuda.ForeColor = System.Drawing.Color.White;
            this.BtnAyuda.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.Ayuda;
            this.BtnAyuda.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnAyuda.Location = new System.Drawing.Point(-1, 267);
            this.BtnAyuda.Name = "BtnAyuda";
            this.BtnAyuda.Size = new System.Drawing.Size(247, 53);
            this.BtnAyuda.TabIndex = 13;
            this.BtnAyuda.Text = "Ayuda";
            this.BtnAyuda.UseVisualStyleBackColor = true;
            this.BtnAyuda.Click += new System.EventHandler(this.BtnAyuda_Click);
            // 
            // BtnAcercaDe
            // 
            this.BtnAcercaDe.FlatAppearance.BorderSize = 0;
            this.BtnAcercaDe.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BtnAcercaDe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAcercaDe.Font = new System.Drawing.Font("Century Gothic", 16F);
            this.BtnAcercaDe.ForeColor = System.Drawing.Color.White;
            this.BtnAcercaDe.Image = global::Pantallas_Sistema_Facturacion.Properties.Resources.Acerca_de;
            this.BtnAcercaDe.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnAcercaDe.Location = new System.Drawing.Point(-1, 326);
            this.BtnAcercaDe.Name = "BtnAcercaDe";
            this.BtnAcercaDe.Size = new System.Drawing.Size(247, 53);
            this.BtnAcercaDe.TabIndex = 12;
            this.BtnAcercaDe.Text = "     Acerca de...";
            this.BtnAcercaDe.UseVisualStyleBackColor = true;
            this.BtnAcercaDe.Click += new System.EventHandler(this.BtnAcercaDe_Click);
            // 
            // PnlMenu
            // 
            this.PnlMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(52)))), ((int)(((byte)(59)))));
            this.PnlMenu.Controls.Add(this.TbpMenu);
            this.PnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.PnlMenu.Location = new System.Drawing.Point(0, 0);
            this.PnlMenu.Name = "PnlMenu";
            this.PnlMenu.Size = new System.Drawing.Size(250, 588);
            this.PnlMenu.TabIndex = 0;
            // 
            // PnlPrincipal
            // 
            this.PnlPrincipal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PnlPrincipal.Controls.Add(this.PnlContenedor);
            this.PnlPrincipal.Controls.Add(this.PnlMenu);
            this.PnlPrincipal.Location = new System.Drawing.Point(0, 63);
            this.PnlPrincipal.Name = "PnlPrincipal";
            this.PnlPrincipal.Size = new System.Drawing.Size(1202, 588);
            this.PnlPrincipal.TabIndex = 0;
            // 
            // PnlContenedor
            // 
            this.PnlContenedor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlContenedor.Location = new System.Drawing.Point(250, 0);
            this.PnlContenedor.Name = "PnlContenedor";
            this.PnlContenedor.Size = new System.Drawing.Size(952, 588);
            this.PnlContenedor.TabIndex = 1;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 650);
            this.Controls.Add(this.TabOpcionesMenu);
            this.Controls.Add(this.PnlPrincipal);
            this.Name = "FrmPrincipal";
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SISTEMA DE FACTURACION";
            this.TbpMenu.ResumeLayout(false);
            this.Principal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Tablas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.Facturacion.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.Seguridad.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.Ayuda.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.PnlMenu.ResumeLayout(false);
            this.PnlPrincipal.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private MaterialSkin.Controls.MaterialTabSelector TabOpcionesMenu;
        private MaterialSkin.Controls.MaterialTabControl TbpMenu;
        private System.Windows.Forms.TabPage Principal;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage Tablas;
        private System.Windows.Forms.TabPage Facturacion;
        private System.Windows.Forms.TabPage Seguridad;
        private System.Windows.Forms.TabPage Ayuda;
        private System.Windows.Forms.Panel PnlMenu;
        private System.Windows.Forms.Panel PnlPrincipal;
        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.Button BtnCategorias;
        private System.Windows.Forms.Button BtnClientes;
        private System.Windows.Forms.Button BtnProductos;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button BtnFacturas;
        private System.Windows.Forms.Button BtnInformes;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button BtnSeguridad;
        private System.Windows.Forms.Button BtnEmpleados;
        private System.Windows.Forms.Button BtnRoles;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button BtnAyuda;
        private System.Windows.Forms.Button BtnAcercaDe;
        private System.Windows.Forms.Panel PnlContenedor;
    }
}