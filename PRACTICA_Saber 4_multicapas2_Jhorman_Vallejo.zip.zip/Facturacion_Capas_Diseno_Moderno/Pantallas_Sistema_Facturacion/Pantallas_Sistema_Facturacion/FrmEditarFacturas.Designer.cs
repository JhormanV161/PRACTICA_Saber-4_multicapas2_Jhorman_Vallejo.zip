namespace Pantallas_Sistema_Facturacion
{
    partial class FrmEditarFacturas
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TxtIdFactura = new System.Windows.Forms.TextBox();
            this.BtnSalir = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnActualizar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.TxtTotal = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.TxtFecha = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.TxtCliente = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.LblTitulo = new MaterialSkin.Controls.MaterialLabel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtIdFactura
            // 
            this.TxtIdFactura.Location = new System.Drawing.Point(47, 177);
            this.TxtIdFactura.Name = "TxtIdFactura";
            this.TxtIdFactura.Size = new System.Drawing.Size(40, 22);
            this.TxtIdFactura.TabIndex = 17;
            // 
            // BtnSalir
            // 
            this.BtnSalir.Depth = 0;
            this.BtnSalir.Location = new System.Drawing.Point(377, 450);
            this.BtnSalir.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Primary = true;
            this.BtnSalir.Size = new System.Drawing.Size(135, 28);
            this.BtnSalir.TabIndex = 16;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.Depth = 0;
            this.BtnActualizar.Location = new System.Drawing.Point(196, 450);
            this.BtnActualizar.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Primary = true;
            this.BtnActualizar.Size = new System.Drawing.Size(135, 28);
            this.BtnActualizar.TabIndex = 15;
            this.BtnActualizar.Text = "Actualizar";
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // TxtTotal
            // 
            this.TxtTotal.Depth = 0;
            this.TxtTotal.Hint = "Total";
            this.TxtTotal.Location = new System.Drawing.Point(71, 288);
            this.TxtTotal.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtTotal.Name = "TxtTotal";
            this.TxtTotal.PasswordChar = '\0';
            this.TxtTotal.SelectedText = "";
            this.TxtTotal.SelectionLength = 0;
            this.TxtTotal.SelectionStart = 0;
            this.TxtTotal.Size = new System.Drawing.Size(492, 28);
            this.TxtTotal.TabIndex = 14;
            this.TxtTotal.UseSystemPasswordChar = false;
            // 
            // TxtFecha
            // 
            this.TxtFecha.Depth = 0;
            this.TxtFecha.Hint = "Fecha";
            this.TxtFecha.Location = new System.Drawing.Point(71, 254);
            this.TxtFecha.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtFecha.Name = "TxtFecha";
            this.TxtFecha.PasswordChar = '\0';
            this.TxtFecha.SelectedText = "";
            this.TxtFecha.SelectionLength = 0;
            this.TxtFecha.SelectionStart = 0;
            this.TxtFecha.Size = new System.Drawing.Size(492, 28);
            this.TxtFecha.TabIndex = 13;
            this.TxtFecha.UseSystemPasswordChar = false;
            // 
            // TxtCliente
            // 
            this.TxtCliente.Depth = 0;
            this.TxtCliente.Hint = "Cliente";
            this.TxtCliente.Location = new System.Drawing.Point(71, 220);
            this.TxtCliente.MouseState = MaterialSkin.MouseState.HOVER;
            this.TxtCliente.Name = "TxtCliente";
            this.TxtCliente.PasswordChar = '\0';
            this.TxtCliente.SelectedText = "";
            this.TxtCliente.SelectionLength = 0;
            this.TxtCliente.SelectionStart = 0;
            this.TxtCliente.Size = new System.Drawing.Size(492, 28);
            this.TxtCliente.TabIndex = 10;
            this.TxtCliente.UseSystemPasswordChar = false;
            // 
            // LblTitulo
            // 
            this.LblTitulo.AutoSize = true;
            this.LblTitulo.Depth = 0;
            this.LblTitulo.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblTitulo.Location = new System.Drawing.Point(272, 46);
            this.LblTitulo.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(165, 24);
            this.LblTitulo.TabIndex = 9;
            this.LblTitulo.Text = "Actualizar Factura";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FrmEditarFacturas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 561);
            this.Controls.Add(this.TxtIdFactura);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnActualizar);
            this.Controls.Add(this.TxtTotal);
            this.Controls.Add(this.TxtFecha);
            this.Controls.Add(this.TxtCliente);
            this.Controls.Add(this.LblTitulo);
            this.Name = "FrmEditarFacturas";
            this.Text = "Editar Factura";
            this.Load += new System.EventHandler(this.FrmEditarFacturas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox TxtIdFactura;
        private MaterialSkin.Controls.MaterialRaisedButton BtnSalir;
        private MaterialSkin.Controls.MaterialRaisedButton BtnActualizar;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtTotal;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtFecha;
        private MaterialSkin.Controls.MaterialSingleLineTextField TxtCliente;
        private MaterialSkin.Controls.MaterialLabel LblTitulo;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}
