﻿using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmListaProducto : Form
    {
        public FrmListaProducto()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable();
        Cls_Productos producto = new Cls_Productos();

        private void Llenar_Grid()
        {
            DgProductos.Rows.Clear();
            dt = producto.Consulta_Producto();
            if (dt == null || dt.Rows.Count == 0)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgProductos.Rows.Add(
                    row["IdProducto"],
                    row["StrNombre"],
                    row["StrDescripcion"],
                    row["NumPrecioVenta"],
                    row["NumStock"]);
            }
        }

        private void FrmListaProductos_Load(object sender, EventArgs e)
        {
            Llenar_Grid();
        }

        private int ObtenerSiguienteId()
        {
            int max = 0;
            foreach (DataGridViewRow row in DgProductos.Rows)
            {
                if (row.Cells["Id_Producto"].Value != null &&
                    int.TryParse(row.Cells["Id_Producto"].Value.ToString(), out int id) &&
                    id > max)
                {
                    max = id;
                }
            }
            return max + 1;
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            FrmEditarProductos frm = new FrmEditarProductos
            {
                IdProducto = 0,
                IdAsignado = ObtenerSiguienteId()
            };

            if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                Llenar_Grid();
        }

        private void DgProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            string columna = DgProductos.Columns[e.ColumnIndex].Name;
            int posActual = e.RowIndex;

            if (columna == "BtnBorrar")
            {
                if (MessageBox.Show("Seguro de borrar", "CONFIRMACION",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    producto.C_IdProducto = int.Parse(
                        DgProductos.Rows[posActual].Cells["Id_Producto"].Value.ToString());
                    string resultado = producto.EliminarProducto();

                    if (resultado.Contains("REFERENCE"))
                        MessageBox.Show("No se puede eliminar: este producto está en una factura.");
                    else
                        MessageBox.Show(resultado);

                    Llenar_Grid();
                }
            }
            else if (columna == "BtnEditar")
            {
                FrmEditarProductos frm = new FrmEditarProductos
                {
                    IdProducto = int.Parse(
                        DgProductos.Rows[posActual].Cells["Id_Producto"].Value.ToString())
                };

                if (frm.ShowDialog(FindForm()) == DialogResult.OK)
                    Llenar_Grid();
            }

            DgProductos.EndEdit();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            DgProductos.Rows.Clear();
            if (TxtBuscarProducto.Text != "")
                dt = producto.Filtrar_Producto(TxtBuscarProducto.Text);
            else
                dt = producto.Consulta_Producto();

            if (dt == null)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgProductos.Rows.Add(
                    row["IdProducto"],
                    row["StrNombre"],
                    row["StrDescripcion"],
                    row["NumPrecioVenta"],
                    row["NumStock"]);
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}