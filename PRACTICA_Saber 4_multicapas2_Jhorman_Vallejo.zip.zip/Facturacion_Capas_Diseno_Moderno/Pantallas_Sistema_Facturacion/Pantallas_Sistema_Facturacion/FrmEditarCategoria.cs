using System;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmEditarCategoria : Form
    {
        public int IdCategoria { get; set; }
        public int IdAsignado { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }

        public FrmEditarCategoria()
        {
            InitializeComponent();
        }

        Acceso_datos Acceso = new Acceso_datos();

        private void FrmEditarCategoria_Load(object sender, EventArgs e)
        {
            TxtIdCategoria.ReadOnly = true;

            if (IdCategoria == 0)
            {
                LblTitulo.Text = "INGRESO NUEVA CATEGORIA";
                TxtIdCategoria.Text = IdAsignado.ToString();
            }
            else
            {
                LblTitulo.Text = "MODIFICAR CATEGORIA";
                TxtIdCategoria.Text = IdCategoria.ToString();
                TxtNombre.Text = Nombre ?? string.Empty;
                TxtDescripcion.Text = Descripcion ?? string.Empty;
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            bool valido = true;

            if (string.IsNullOrWhiteSpace(TxtNombre.Text))
            {
                errorProvider1.SetError(TxtNombre, "El nombre es obligatorio.");
                valido = false;
            }
            if (!valido)
                return;

            string sentencia = $"Exec actualizar_CategoriaProd {IdCategoria}," +
                $"'{TxtNombre.Text}'," +
                $"'{DateTime.Now:yyyy-MM-dd}'," +
                $"'Jhorman'";

            MessageBox.Show(Acceso.EjecutarComando(sentencia));
            DialogResult = DialogResult.OK;
            Close();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
