namespace Pantallas_Sistema_Facturacion
{
    partial class FrmInformes
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.LblTitulo = new System.Windows.Forms.Label();
            this.LblSeleccioneInforme = new System.Windows.Forms.Label();
            this.CmbInforme = new System.Windows.Forms.ComboBox();
            this.LblOrdenar = new System.Windows.Forms.Label();
            this.CmbOrdenar = new System.Windows.Forms.ComboBox();
            this.LblFechaInicio = new System.Windows.Forms.Label();
            this.DtpFechaInicio = new System.Windows.Forms.DateTimePicker();
            this.LblFechaFinal = new System.Windows.Forms.Label();
            this.DtpFechaFinal = new System.Windows.Forms.DateTimePicker();
            this.RdbPantalla = new System.Windows.Forms.RadioButton();
            this.RdbPdf = new System.Windows.Forms.RadioButton();
            this.RdbExcel = new System.Windows.Forms.RadioButton();
            this.BtnGenerar = new System.Windows.Forms.Button();
            this.BtnSalir = new System.Windows.Forms.Button();
            this.DgInforme = new System.Windows.Forms.DataGridView();
            this.ColId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDescripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColValor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DgInforme)).BeginInit();
            this.SuspendLayout();
            // 
            // LblTitulo
            // 
            this.LblTitulo.Location = new System.Drawing.Point(220, 12);
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(440, 28);
            this.LblTitulo.TabIndex = 0;
            this.LblTitulo.Text = "GENERADOR DE INFORMES DE FACTURACION";
            this.LblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblSeleccioneInforme
            // 
            this.LblSeleccioneInforme.Location = new System.Drawing.Point(20, 55);
            this.LblSeleccioneInforme.Name = "LblSeleccioneInforme";
            this.LblSeleccioneInforme.Size = new System.Drawing.Size(160, 20);
            this.LblSeleccioneInforme.TabIndex = 1;
            this.LblSeleccioneInforme.Text = "SELECCIONE INFORME";
            // 
            // CmbInforme
            // 
            this.CmbInforme.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbInforme.FormattingEnabled = true;
            this.CmbInforme.Items.AddRange(new object[] {
            "Ventas por periodo",
            "Productos mas vendidos",
            "Clientes activos",
            "Facturas pendientes"});
            this.CmbInforme.Location = new System.Drawing.Point(20, 78);
            this.CmbInforme.Name = "CmbInforme";
            this.CmbInforme.Size = new System.Drawing.Size(420, 24);
            this.CmbInforme.TabIndex = 2;
            // 
            // LblOrdenar
            // 
            this.LblOrdenar.Location = new System.Drawing.Point(460, 55);
            this.LblOrdenar.Name = "LblOrdenar";
            this.LblOrdenar.Size = new System.Drawing.Size(90, 20);
            this.LblOrdenar.TabIndex = 3;
            this.LblOrdenar.Text = "Ordenar por";
            // 
            // CmbOrdenar
            // 
            this.CmbOrdenar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbOrdenar.FormattingEnabled = true;
            this.CmbOrdenar.Items.AddRange(new object[] {
            "Fecha",
            "Cliente",
            "Total",
            "Producto"});
            this.CmbOrdenar.Location = new System.Drawing.Point(460, 78);
            this.CmbOrdenar.Name = "CmbOrdenar";
            this.CmbOrdenar.Size = new System.Drawing.Size(200, 24);
            this.CmbOrdenar.TabIndex = 4;
            // 
            // LblFechaInicio
            // 
            this.LblFechaInicio.Location = new System.Drawing.Point(20, 115);
            this.LblFechaInicio.Name = "LblFechaInicio";
            this.LblFechaInicio.Size = new System.Drawing.Size(100, 20);
            this.LblFechaInicio.TabIndex = 5;
            this.LblFechaInicio.Text = "Fecha Inicio";
            // 
            // DtpFechaInicio
            // 
            this.DtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DtpFechaInicio.Location = new System.Drawing.Point(20, 138);
            this.DtpFechaInicio.Name = "DtpFechaInicio";
            this.DtpFechaInicio.Size = new System.Drawing.Size(200, 22);
            this.DtpFechaInicio.TabIndex = 6;
            // 
            // LblFechaFinal
            // 
            this.LblFechaFinal.Location = new System.Drawing.Point(240, 115);
            this.LblFechaFinal.Name = "LblFechaFinal";
            this.LblFechaFinal.Size = new System.Drawing.Size(100, 20);
            this.LblFechaFinal.TabIndex = 7;
            this.LblFechaFinal.Text = "Fecha Final";
            // 
            // DtpFechaFinal
            // 
            this.DtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DtpFechaFinal.Location = new System.Drawing.Point(240, 138);
            this.DtpFechaFinal.Name = "DtpFechaFinal";
            this.DtpFechaFinal.Size = new System.Drawing.Size(200, 22);
            this.DtpFechaFinal.TabIndex = 8;
            // 
            // RdbPantalla
            // 
            this.RdbPantalla.AutoSize = true;
            this.RdbPantalla.Checked = true;
            this.RdbPantalla.Location = new System.Drawing.Point(460, 115);
            this.RdbPantalla.Name = "RdbPantalla";
            this.RdbPantalla.Size = new System.Drawing.Size(103, 20);
            this.RdbPantalla.TabIndex = 9;
            this.RdbPantalla.TabStop = true;
            this.RdbPantalla.Text = "En Pantalla";
            this.RdbPantalla.UseVisualStyleBackColor = true;
            // 
            // RdbPdf
            // 
            this.RdbPdf.AutoSize = true;
            this.RdbPdf.Location = new System.Drawing.Point(460, 138);
            this.RdbPdf.Name = "RdbPdf";
            this.RdbPdf.Size = new System.Drawing.Size(48, 20);
            this.RdbPdf.TabIndex = 10;
            this.RdbPdf.Text = "Pdf";
            this.RdbPdf.UseVisualStyleBackColor = true;
            // 
            // RdbExcel
            // 
            this.RdbExcel.AutoSize = true;
            this.RdbExcel.Location = new System.Drawing.Point(530, 138);
            this.RdbExcel.Name = "RdbExcel";
            this.RdbExcel.Size = new System.Drawing.Size(58, 20);
            this.RdbExcel.TabIndex = 11;
            this.RdbExcel.Text = "Excel";
            this.RdbExcel.UseVisualStyleBackColor = true;
            // 
            // BtnGenerar
            // 
            this.BtnGenerar.Location = new System.Drawing.Point(680, 78);
            this.BtnGenerar.Name = "BtnGenerar";
            this.BtnGenerar.Size = new System.Drawing.Size(180, 40);
            this.BtnGenerar.TabIndex = 12;
            this.BtnGenerar.Text = "GENERAR INFORME";
            this.BtnGenerar.UseVisualStyleBackColor = true;
            this.BtnGenerar.Click += new System.EventHandler(this.BtnGenerar_Click);
            // 
            // BtnSalir
            // 
            this.BtnSalir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnSalir.Location = new System.Drawing.Point(680, 520);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(180, 40);
            this.BtnSalir.TabIndex = 13;
            this.BtnSalir.Text = "SALIR";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // DgInforme
            // 
            this.DgInforme.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgInforme.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.DgInforme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgInforme.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColId,
            this.ColDescripcion,
            this.ColValor});
            this.DgInforme.Location = new System.Drawing.Point(20, 180);
            this.DgInforme.Name = "DgInforme";
            this.DgInforme.RowHeadersWidth = 51;
            this.DgInforme.RowTemplate.Height = 24;
            this.DgInforme.Size = new System.Drawing.Size(840, 320);
            this.DgInforme.TabIndex = 14;
            // 
            // ColId
            // 
            this.ColId.HeaderText = "ID";
            this.ColId.MinimumWidth = 6;
            this.ColId.Name = "ColId";
            this.ColId.Width = 80;
            // 
            // ColDescripcion
            // 
            this.ColDescripcion.HeaderText = "DESCRIPCION";
            this.ColDescripcion.MinimumWidth = 6;
            this.ColDescripcion.Name = "ColDescripcion";
            this.ColDescripcion.Width = 450;
            // 
            // ColValor
            // 
            this.ColValor.HeaderText = "VALOR";
            this.ColValor.MinimumWidth = 6;
            this.ColValor.Name = "ColValor";
            this.ColValor.Width = 150;
            // 
            // FrmInformes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(880, 580);
            this.Controls.Add(this.DgInforme);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnGenerar);
            this.Controls.Add(this.RdbExcel);
            this.Controls.Add(this.RdbPdf);
            this.Controls.Add(this.RdbPantalla);
            this.Controls.Add(this.DtpFechaFinal);
            this.Controls.Add(this.LblFechaFinal);
            this.Controls.Add(this.DtpFechaInicio);
            this.Controls.Add(this.LblFechaInicio);
            this.Controls.Add(this.CmbOrdenar);
            this.Controls.Add(this.LblOrdenar);
            this.Controls.Add(this.CmbInforme);
            this.Controls.Add(this.LblSeleccioneInforme);
            this.Controls.Add(this.LblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmInformes";
            this.Text = "frmInformes";
            this.Load += new System.EventHandler(this.FrmInformes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DgInforme)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label LblTitulo;
        private System.Windows.Forms.Label LblSeleccioneInforme;
        private System.Windows.Forms.ComboBox CmbInforme;
        private System.Windows.Forms.Label LblOrdenar;
        private System.Windows.Forms.ComboBox CmbOrdenar;
        private System.Windows.Forms.Label LblFechaInicio;
        private System.Windows.Forms.DateTimePicker DtpFechaInicio;
        private System.Windows.Forms.Label LblFechaFinal;
        private System.Windows.Forms.DateTimePicker DtpFechaFinal;
        private System.Windows.Forms.RadioButton RdbPantalla;
        private System.Windows.Forms.RadioButton RdbPdf;
        private System.Windows.Forms.RadioButton RdbExcel;
        private System.Windows.Forms.Button BtnGenerar;
        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.DataGridView DgInforme;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDescripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColValor;
    }
}
