using System;
using System.Data;
using System.Windows.Forms;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmAdminSeguridad : Form
    {
        DataTable dt = new DataTable();
        Cls_Seguridad SeguridadEmpleado = new Cls_Seguridad();

        public FrmAdminSeguridad()
        {
            InitializeComponent();
            UiEstilo.AplicarTitulo(LblTitulo);
            UiEstilo.AplicarEtiqueta(LblEmpleado);
            UiEstilo.AplicarEtiqueta(LblUsuario);
            UiEstilo.AplicarEtiqueta(LblClave);
            UiEstilo.AplicarBoton(BtnActualizar);
            UiEstilo.AplicarBoton(BtnEliminar);
            UiEstilo.AplicarBoton(BtnSalir);
        }

        private void FrmAdminSeguridad_Load(object sender, EventArgs e)
        {
            Llenar_combo_Empleados();
        }

        private void Llenar_combo_Empleados()
        {
            CmbEmpleado.DisplayMember = "strNombre";
            CmbEmpleado.ValueMember = "IdEmpleado";
            CmbEmpleado.DataSource = SeguridadEmpleado.ConsultarEmpleados();
        }

        private void Consultar()
        {
            if (CmbEmpleado.SelectedValue == null || CmbEmpleado.SelectedValue is DataRowView)
                return;

            int IdEmpleado = Convert.ToInt32(CmbEmpleado.SelectedValue);
            dt = SeguridadEmpleado.Consulta_SeguridadEmpleado(IdEmpleado);

            if (dt != null && dt.Rows.Count > 0)
            {
                TxtUsuario.Text = dt.Rows[0]["StrUsuario"].ToString();
                TxtClave.Text = dt.Rows[0]["StrClave"].ToString();
            }
            else
            {
                TxtUsuario.Text = "";
                TxtClave.Text = "";
            }
        }

        private void CmbEmpleado_SelectedIndexChanged(object sender, EventArgs e)
        {
            Consultar();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            Guardar();
        }

        private void Guardar()
        {
            errorProvider1.Clear();
            bool valido = true;

            if (CmbEmpleado.SelectedValue == null || CmbEmpleado.SelectedValue is DataRowView)
            {
                errorProvider1.SetError(CmbEmpleado, "Debe seleccionar un empleado.");
                valido = false;
            }
            if (string.IsNullOrWhiteSpace(TxtUsuario.Text))
            {
                errorProvider1.SetError(TxtUsuario, "El usuario es obligatorio.");
                valido = false;
            }
            if (string.IsNullOrWhiteSpace(TxtClave.Text))
            {
                errorProvider1.SetError(TxtClave, "La clave es obligatoria.");
                valido = false;
            }
            if (!valido)
                return;

            SeguridadEmpleado.C_IdEmpleado = Convert.ToInt32(CmbEmpleado.SelectedValue);
            SeguridadEmpleado.C_StrUsuario = TxtUsuario.Text;
            SeguridadEmpleado.C_StrClave = TxtClave.Text;
            SeguridadEmpleado.C_StrUsuarioModifico = "Jhorman";
            MessageBox.Show(SeguridadEmpleado.ActualizarSeguridadEmpleado());
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            Eliminar();
        }

        private void Eliminar()
        {
            if (CmbEmpleado.SelectedValue == null || CmbEmpleado.SelectedValue is DataRowView)
            {
                MessageBox.Show("Debe seleccionar un empleado.");
                return;
            }

            if (MessageBox.Show("Seguro de eliminar el usuario y la clave de este empleado?",
                "CONFIRMACION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            SeguridadEmpleado.C_IdEmpleado = Convert.ToInt32(CmbEmpleado.SelectedValue);
            MessageBox.Show(SeguridadEmpleado.EliminarSeguridadEmpleado());
            TxtUsuario.Text = "";
            TxtClave.Text = "";
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}