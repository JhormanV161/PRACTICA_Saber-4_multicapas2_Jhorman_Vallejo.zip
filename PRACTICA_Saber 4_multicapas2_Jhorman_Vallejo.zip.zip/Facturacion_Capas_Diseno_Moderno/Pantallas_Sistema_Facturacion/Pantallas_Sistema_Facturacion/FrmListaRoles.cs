using System;
using System.Data;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmListaRoles : Form
    {
        public FrmListaRoles()
        {
            InitializeComponent();
        }

        Acceso_datos Acceso = new Acceso_datos();
        DataTable dt = new DataTable();

        private void Llenar_Grid()
        {
            DgRoles.Rows.Clear();

            dt = Acceso.EjecutarComandoDatos("select IdRolEmpleado, StrDescripcion from TBLROLES");
            if (dt == null)
                return;

            foreach (DataRow row in dt.Rows)
            {
                DgRoles.Rows.Add(
                    row["IdRolEmpleado"],
                    row["StrDescripcion"],
                    row["StrDescripcion"]);
            }
        }

        private void FrmListaRoles_Load(object sender, EventArgs e)
        {
            Llenar_Grid();
        }

        private int ObtenerSiguienteId()
        {
            int max = 0;
            foreach (DataGridViewRow row in DgRoles.Rows)
            {
                if (row.Cells["Id_Rol"].Value != null &&
                    int.TryParse(row.Cells["Id_Rol"].Value.ToString(), out int id) &&
                    id > max)
                {
                    max = id;
                }
            }
            return max + 1;
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            FrmEditarRoles rol = new FrmEditarRoles
            {
                IdRol = 0,
                IdAsignado = ObtenerSiguienteId()
            };
            UiEstilo.PrepararDialogo(rol);

            if (rol.ShowDialog(FindForm()) == DialogResult.OK)
            {
                Llenar_Grid();
            }
        }

        private void DgRoles_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            string columna = DgRoles.Columns[e.ColumnIndex].Name;
            int posActual = e.RowIndex;

            if (columna == "BtnBorrar")
            {
                if (MessageBox.Show("Seguro de borrar", "CONFIRMACION",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string id = DgRoles.Rows[posActual].Cells["Id_Rol"].Value.ToString();
                    string sentencia = $"delete from TBLROLES where IdRolEmpleado = {id}";
                    string resultado = Acceso.EjecutarComando(sentencia);

                    if (resultado.Contains("REFERENCE"))
                        MessageBox.Show("No se puede eliminar: hay empleados con este rol.");
                    else
                        MessageBox.Show(resultado);

                    Llenar_Grid();
                }
            }

            else if (columna == "BtnEditar")
            {
                FrmEditarRoles rol = new FrmEditarRoles
                {
                    IdRol = int.Parse(DgRoles.Rows[posActual].Cells["Id_Rol"].Value.ToString()),
                    Nombre = DgRoles.Rows[posActual].Cells["StrRol"].Value?.ToString(),
                    Descripcion = DgRoles.Rows[posActual].Cells["StrDescripcion"].Value?.ToString()
                };
                UiEstilo.PrepararDialogo(rol);

                if (rol.ShowDialog(FindForm()) == DialogResult.OK)
                {
                    Llenar_Grid();
                }
            }

            DgRoles.EndEdit();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            DgRoles.Rows.Clear();
            string sentencia = "select IdRolEmpleado, StrDescripcion from TBLROLES";
            if (TxtBuscarRol.Text != "")
                sentencia += $" where StrDescripcion like '%{TxtBuscarRol.Text}%'";
            dt = Acceso.EjecutarComandoDatos(sentencia);
            if (dt == null)
                return;
            foreach (DataRow row in dt.Rows)
            {
                DgRoles.Rows.Add(
                    row["IdRolEmpleado"],
                    row["StrDescripcion"],
                    row["StrDescripcion"]);
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
