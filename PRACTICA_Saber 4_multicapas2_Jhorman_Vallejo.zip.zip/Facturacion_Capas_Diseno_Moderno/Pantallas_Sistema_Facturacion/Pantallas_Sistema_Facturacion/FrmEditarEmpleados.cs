using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmEditarEmpleados : Form
    {
        public int IdEmpleado { get; set; }
        public int IdAsignado { get; set; }

        DataTable dt = new DataTable();
        Cls_Empleados empleado = new Cls_Empleados();

        public FrmEditarEmpleados()
        {
            InitializeComponent();
            UiEstilo.AplicarTitulo(LblTitulo);
            UiEstilo.AplicarEtiqueta(LblNombre);
            UiEstilo.AplicarEtiqueta(LblDocumento);
            UiEstilo.AplicarEtiqueta(LblDireccion);
            UiEstilo.AplicarEtiqueta(LblTelefono);
            UiEstilo.AplicarEtiqueta(LblEmail);
            UiEstilo.AplicarEtiqueta(LblRol);
            UiEstilo.AplicarEtiqueta(LblFIngreso);
            UiEstilo.AplicarEtiqueta(LblFRetiro);
            UiEstilo.AplicarEtiqueta(LblDatosAdicionales);
            UiEstilo.AplicarBoton(BtnActualizar);
            UiEstilo.AplicarBoton(BtnSalir);
        }

        private void FrmEditarEmpleados_Load(object sender, EventArgs e)
        {
            Llenar_combo();
            TxtIdEmpleado.ReadOnly = true;

            if (IdEmpleado == 0)
            {
                LblTitulo.Text = "INGRESO NUEVO EMPLEADO";
                TxtIdEmpleado.Text = IdAsignado.ToString();
            }
            else
            {
                LblTitulo.Text = "MODIFICAR EMPLEADO";
                TxtIdEmpleado.Text = IdEmpleado.ToString();
                Llenar_campos();
            }
        }

        private void Llenar_combo()
        {
            CmbRol.DisplayMember = "StrDescripcion";
            CmbRol.ValueMember = "IdRolEmpleado";
            CmbRol.DataSource = empleado.ConsultarRol();
        }

        private void Llenar_campos()
        {
            dt = empleado.Consulta_Empleado(IdEmpleado);
            if (dt == null || dt.Rows.Count == 0)
                return;

            DataRow row = dt.Rows[0];
            TxtNombre.Text = row["strNombre"].ToString();
            TxtDocumento.Text = row["NumDocumento"].ToString();
            TxtDireccion.Text = row["StrDireccion"].ToString();
            TxtTelefono.Text = row["StrTelefono"].ToString();
            TxtEmail.Text = row["StrEmail"].ToString();
            CmbRol.SelectedValue = Convert.ToInt32(row["IdRolEmpleado"]);
            if (row["DtmIngreso"] != DBNull.Value)
                DtpFIngreso.Value = Convert.ToDateTime(row["DtmIngreso"]);
            if (row["DtmRetiro"] != DBNull.Value)
                DtpFRetiro.Value = Convert.ToDateTime(row["DtmRetiro"]);
            TxtDatosAdicionales.Text = row["strDatosAdicionales"].ToString();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            Guardar();
        }

        private void Guardar()
        {
            if (!Validar())
                return;

            empleado.C_IdEmpleado = IdEmpleado;
            empleado.C_strNombre = TxtNombre.Text;
            empleado.C_NumDocumento = double.Parse(TxtDocumento.Text);
            empleado.C_StrDireccion = TxtDireccion.Text;
            empleado.C_StrTelefono = TxtTelefono.Text;
            empleado.C_StrEmail = TxtEmail.Text;
            empleado.C_IdRolEmpleado = Convert.ToInt32(CmbRol.SelectedValue);
            empleado.C_DtmIngreso = DtpFIngreso.Value;
            empleado.C_DtmRetiro = DtpFRetiro.Value;
            empleado.C_strDatosAdicionales = TxtDatosAdicionales.Text;
            empleado.C_StrUsuarioModifico = "Jhorman";

            MessageBox.Show(empleado.ActualizarEmpleado());
            DialogResult = DialogResult.OK;
            Close();
        }

        private bool Validar()
        {
            errorProvider1.Clear();
            bool valido = true;

            if (string.IsNullOrWhiteSpace(TxtNombre.Text))
            {
                errorProvider1.SetError(TxtNombre, "El nombre es obligatorio.");
                valido = false;
            }
            if (string.IsNullOrWhiteSpace(TxtDocumento.Text))
            {
                errorProvider1.SetError(TxtDocumento, "El documento es obligatorio.");
                valido = false;
            }
            else if (!double.TryParse(TxtDocumento.Text, out _))
            {
                errorProvider1.SetError(TxtDocumento, "El documento debe ser numerico.");
                valido = false;
            }
            if (CmbRol.SelectedValue == null || CmbRol.SelectedValue is DataRowView)
            {
                errorProvider1.SetError(CmbRol, "Debe seleccionar un rol.");
                valido = false;
            }
            return valido;
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}