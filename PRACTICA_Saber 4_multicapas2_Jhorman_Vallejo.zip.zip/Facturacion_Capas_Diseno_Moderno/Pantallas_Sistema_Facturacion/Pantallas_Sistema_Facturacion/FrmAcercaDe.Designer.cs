namespace Pantallas_Sistema_Facturacion
{
    partial class FrmAcercaDe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.PnlContenido = new System.Windows.Forms.Panel();
            this.BtnAceptar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.TxtLegal = new System.Windows.Forms.TextBox();
            this.BtnDxDiag = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnInfoSistema = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BtnCopiarInfo = new MaterialSkin.Controls.MaterialRaisedButton();
            this.LstProductos = new System.Windows.Forms.ListBox();
            this.LblProductosInstalados = new MaterialSkin.Controls.MaterialLabel();
            this.LblCopyright = new MaterialSkin.Controls.MaterialLabel();
            this.LblVersion = new MaterialSkin.Controls.MaterialLabel();
            this.LblProducto = new MaterialSkin.Controls.MaterialLabel();
            this.LnkTerminos = new System.Windows.Forms.LinkLabel();
            this.LnkLicencia = new System.Windows.Forms.LinkLabel();
            this.LblTitulo = new MaterialSkin.Controls.MaterialLabel();
            this.PnlContenido.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlContenido
            // 
            this.PnlContenido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PnlContenido.Controls.Add(this.BtnAceptar);
            this.PnlContenido.Controls.Add(this.TxtLegal);
            this.PnlContenido.Controls.Add(this.BtnDxDiag);
            this.PnlContenido.Controls.Add(this.BtnInfoSistema);
            this.PnlContenido.Controls.Add(this.BtnCopiarInfo);
            this.PnlContenido.Controls.Add(this.LstProductos);
            this.PnlContenido.Controls.Add(this.LblProductosInstalados);
            this.PnlContenido.Controls.Add(this.LblCopyright);
            this.PnlContenido.Controls.Add(this.LblVersion);
            this.PnlContenido.Controls.Add(this.LblProducto);
            this.PnlContenido.Controls.Add(this.LnkTerminos);
            this.PnlContenido.Controls.Add(this.LnkLicencia);
            this.PnlContenido.Controls.Add(this.LblTitulo);
            this.PnlContenido.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlContenido.Location = new System.Drawing.Point(0, 0);
            this.PnlContenido.Name = "PnlContenido";
            this.PnlContenido.Size = new System.Drawing.Size(614, 458);
            this.PnlContenido.TabIndex = 0;
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.Depth = 0;
            this.BtnAceptar.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAceptar.Location = new System.Drawing.Point(470, 410);
            this.BtnAceptar.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Primary = true;
            this.BtnAceptar.Size = new System.Drawing.Size(120, 32);
            this.BtnAceptar.TabIndex = 12;
            this.BtnAceptar.Text = "Aceptar";
            this.BtnAceptar.UseVisualStyleBackColor = true;
            this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
            // 
            // TxtLegal
            // 
            this.TxtLegal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TxtLegal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtLegal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.TxtLegal.Location = new System.Drawing.Point(30, 336);
            this.TxtLegal.Multiline = true;
            this.TxtLegal.Name = "TxtLegal";
            this.TxtLegal.ReadOnly = true;
            this.TxtLegal.Size = new System.Drawing.Size(560, 64);
            this.TxtLegal.TabIndex = 11;
            this.TxtLegal.Text = "Advertencia: este programa esta protegido por las leyes de derechos de autor. La " +
    "reproduccion o distribucion no autorizada de este programa, total o parcialmente" +
    ", puede ser constitutiva de un delito.";
            // 
            // BtnDxDiag
            // 
            this.BtnDxDiag.Depth = 0;
            this.BtnDxDiag.Location = new System.Drawing.Point(440, 290);
            this.BtnDxDiag.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnDxDiag.Name = "BtnDxDiag";
            this.BtnDxDiag.Primary = true;
            this.BtnDxDiag.Size = new System.Drawing.Size(150, 28);
            this.BtnDxDiag.TabIndex = 10;
            this.BtnDxDiag.Text = "DxDiag";
            this.BtnDxDiag.UseVisualStyleBackColor = true;
            this.BtnDxDiag.Click += new System.EventHandler(this.BtnDxDiag_Click);
            // 
            // BtnInfoSistema
            // 
            this.BtnInfoSistema.Depth = 0;
            this.BtnInfoSistema.Location = new System.Drawing.Point(440, 238);
            this.BtnInfoSistema.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnInfoSistema.Name = "BtnInfoSistema";
            this.BtnInfoSistema.Primary = true;
            this.BtnInfoSistema.Size = new System.Drawing.Size(150, 46);
            this.BtnInfoSistema.TabIndex = 9;
            this.BtnInfoSistema.Text = "Info. del sistema";
            this.BtnInfoSistema.UseVisualStyleBackColor = true;
            this.BtnInfoSistema.Click += new System.EventHandler(this.BtnInfoSistema_Click);
            // 
            // BtnCopiarInfo
            // 
            this.BtnCopiarInfo.Depth = 0;
            this.BtnCopiarInfo.Location = new System.Drawing.Point(440, 188);
            this.BtnCopiarInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.BtnCopiarInfo.Name = "BtnCopiarInfo";
            this.BtnCopiarInfo.Primary = true;
            this.BtnCopiarInfo.Size = new System.Drawing.Size(150, 43);
            this.BtnCopiarInfo.TabIndex = 8;
            this.BtnCopiarInfo.Text = "Copiar informacion";
            this.BtnCopiarInfo.UseVisualStyleBackColor = true;
            this.BtnCopiarInfo.Click += new System.EventHandler(this.BtnCopiarInfo_Click);
            // 
            // LstProductos
            // 
            this.LstProductos.BackColor = System.Drawing.Color.White;
            this.LstProductos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LstProductos.FormattingEnabled = true;
            this.LstProductos.ItemHeight = 16;
            this.LstProductos.Location = new System.Drawing.Point(30, 188);
            this.LstProductos.Name = "LstProductos";
            this.LstProductos.Size = new System.Drawing.Size(390, 130);
            this.LstProductos.TabIndex = 7;
            this.LstProductos.SelectedIndexChanged += new System.EventHandler(this.LstProductos_SelectedIndexChanged);
            // 
            // LblProductosInstalados
            // 
            this.LblProductosInstalados.AutoSize = true;
            this.LblProductosInstalados.Depth = 0;
            this.LblProductosInstalados.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblProductosInstalados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblProductosInstalados.Location = new System.Drawing.Point(27, 162);
            this.LblProductosInstalados.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblProductosInstalados.Name = "LblProductosInstalados";
            this.LblProductosInstalados.Size = new System.Drawing.Size(195, 24);
            this.LblProductosInstalados.TabIndex = 6;
            this.LblProductosInstalados.Text = "Productos instalados:";
            // 
            // LblCopyright
            // 
            this.LblCopyright.AutoSize = true;
            this.LblCopyright.Depth = 0;
            this.LblCopyright.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblCopyright.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblCopyright.Location = new System.Drawing.Point(27, 128);
            this.LblCopyright.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblCopyright.Name = "LblCopyright";
            this.LblCopyright.Size = new System.Drawing.Size(515, 24);
            this.LblCopyright.TabIndex = 5;
            this.LblCopyright.Text = "Universidad Pascual Bravo. Todos los derechos reservados.";
            // 
            // LblVersion
            // 
            this.LblVersion.AutoSize = true;
            this.LblVersion.Depth = 0;
            this.LblVersion.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblVersion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblVersion.Location = new System.Drawing.Point(27, 102);
            this.LblVersion.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblVersion.Name = "LblVersion";
            this.LblVersion.Size = new System.Drawing.Size(305, 24);
            this.LblVersion.TabIndex = 4;
            this.LblVersion.Text = "Version 1.0 - Herramientas Prog. III";
            // 
            // LblProducto
            // 
            this.LblProducto.AutoSize = true;
            this.LblProducto.Depth = 0;
            this.LblProducto.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblProducto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblProducto.Location = new System.Drawing.Point(26, 72);
            this.LblProducto.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblProducto.Name = "LblProducto";
            this.LblProducto.Size = new System.Drawing.Size(209, 24);
            this.LblProducto.TabIndex = 3;
            this.LblProducto.Text = "Sistema de Facturacion";
            // 
            // LnkTerminos
            // 
            this.LnkTerminos.AutoSize = true;
            this.LnkTerminos.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.LnkTerminos.Location = new System.Drawing.Point(28, 430);
            this.LnkTerminos.Name = "LnkTerminos";
            this.LnkTerminos.Size = new System.Drawing.Size(132, 16);
            this.LnkTerminos.TabIndex = 2;
            this.LnkTerminos.TabStop = true;
            this.LnkTerminos.Text = "Terminos de licencia";
            this.LnkTerminos.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnkTerminos_LinkClicked);
            // 
            // LnkLicencia
            // 
            this.LnkLicencia.AutoSize = true;
            this.LnkLicencia.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.LnkLicencia.Location = new System.Drawing.Point(28, 410);
            this.LnkLicencia.Name = "LnkLicencia";
            this.LnkLicencia.Size = new System.Drawing.Size(144, 16);
            this.LnkLicencia.TabIndex = 1;
            this.LnkLicencia.TabStop = true;
            this.LnkLicencia.Text = "Informacion de licencia";
            this.LnkLicencia.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnkLicencia_LinkClicked);
            // 
            // LblTitulo
            // 
            this.LblTitulo.AutoSize = true;
            this.LblTitulo.Depth = 0;
            this.LblTitulo.Font = new System.Drawing.Font("Roboto", 11F);
            this.LblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblTitulo.Location = new System.Drawing.Point(24, 20);
            this.LblTitulo.MouseState = MaterialSkin.MouseState.HOVER;
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(361, 24);
            this.LblTitulo.TabIndex = 0;
            this.LblTitulo.Text = "ACERCA DEL SISTEMA DE FACTURACION";
            // 
            // FrmAcercaDe
            // 
            this.AcceptButton = this.BtnAceptar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(614, 458);
            this.Controls.Add(this.PnlContenido);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmAcercaDe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Acerca del Sistema de Facturacion";
            this.Load += new System.EventHandler(this.FrmAcercaDe_Load);
            this.PnlContenido.ResumeLayout(false);
            this.PnlContenido.PerformLayout();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel PnlContenido;
        private MaterialSkin.Controls.MaterialLabel LblTitulo;
        private System.Windows.Forms.LinkLabel LnkLicencia;
        private System.Windows.Forms.LinkLabel LnkTerminos;
        private MaterialSkin.Controls.MaterialLabel LblProducto;
        private MaterialSkin.Controls.MaterialLabel LblVersion;
        private MaterialSkin.Controls.MaterialLabel LblCopyright;
        private MaterialSkin.Controls.MaterialLabel LblProductosInstalados;
        private System.Windows.Forms.ListBox LstProductos;
        private MaterialSkin.Controls.MaterialRaisedButton BtnCopiarInfo;
        private MaterialSkin.Controls.MaterialRaisedButton BtnInfoSistema;
        private MaterialSkin.Controls.MaterialRaisedButton BtnDxDiag;
        private System.Windows.Forms.TextBox TxtLegal;
        private MaterialSkin.Controls.MaterialRaisedButton BtnAceptar;
    }
}