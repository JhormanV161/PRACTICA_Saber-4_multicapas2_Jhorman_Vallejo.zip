namespace Pantallas_Sistema_Facturacion
{
    partial class FrmAyuda
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.WbAyuda = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // WbAyuda
            // 
            this.WbAyuda.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WbAyuda.Location = new System.Drawing.Point(0, 0);
            this.WbAyuda.MinimumSize = new System.Drawing.Size(20, 20);
            this.WbAyuda.Name = "WbAyuda";
            this.WbAyuda.ScriptErrorsSuppressed = true;
            this.WbAyuda.Size = new System.Drawing.Size(880, 580);
            this.WbAyuda.TabIndex = 0;
            // 
            // FrmAyuda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(880, 580);
            this.Controls.Add(this.WbAyuda);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmAyuda";
            this.Text = "Ayuda";
            this.Load += new System.EventHandler(this.FrmAyuda_Load);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.WebBrowser WbAyuda;
    }
}