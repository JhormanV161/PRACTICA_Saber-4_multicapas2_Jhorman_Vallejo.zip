using System.Drawing;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    internal static class UiEstilo
    {
        public static readonly Color ColorBoton = Color.FromArgb(26, 42, 58);

        public static void AplicarBoton(Button boton)
        {
            boton.BackColor = ColorBoton;
            boton.ForeColor = Color.White;
            boton.FlatStyle = FlatStyle.Flat;
            boton.FlatAppearance.BorderSize = 0;
            boton.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            boton.Cursor = Cursors.Hand;
            boton.UseVisualStyleBackColor = false;
        }

        public static void AplicarTitulo(Label titulo)
        {
            titulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            titulo.ForeColor = Color.Black;
        }

        public static void AplicarEtiqueta(Label etiqueta)
        {
            etiqueta.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            etiqueta.ForeColor = Color.Black;
            etiqueta.AutoSize = true;
        }

        public static void PrepararDialogo(Form formulario)
        {
            formulario.FormBorderStyle = FormBorderStyle.FixedDialog;
            formulario.StartPosition = FormStartPosition.CenterParent;
            formulario.MaximizeBox = false;
            formulario.MinimizeBox = false;
        }

        public static void FiltrarGrilla(DataGridView grilla, string filtro)
        {
            filtro = (filtro ?? string.Empty).Trim().ToLower();

            foreach (DataGridViewRow row in grilla.Rows)
            {
                if (row.IsNewRow)
                    continue;

                if (string.IsNullOrEmpty(filtro))
                {
                    row.Visible = true;
                    continue;
                }

                bool coincide = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    string nombreColumna = cell.OwningColumn.Name;
                    if (nombreColumna == "BtnEditar" || nombreColumna == "BtnBorrar")
                        continue;

                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(filtro))
                    {
                        coincide = true;
                        break;
                    }
                }

                row.Visible = coincide;
            }
        }
    }
}
