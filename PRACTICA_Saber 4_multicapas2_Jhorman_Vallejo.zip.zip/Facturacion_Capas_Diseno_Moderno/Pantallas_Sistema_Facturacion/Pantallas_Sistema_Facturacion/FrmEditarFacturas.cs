using System;
using System.Windows.Forms;
using System.Data;
using Capa_LogicaDeNegocios;

namespace Pantallas_Sistema_Facturacion
{
    public partial class FrmEditarFacturas : Form
    {
        public int IdFactura { get; set; }
        public int IdAsignado { get; set; }

        DataTable dt = new DataTable();
        Cls_Facturas factura = new Cls_Facturas();

        public FrmEditarFacturas()
        {
            InitializeComponent();
        }

        private void FrmEditarFacturas_Load(object sender, EventArgs e)
        {
            TxtIdFactura.ReadOnly = true;

            if (IdFactura == 0)
            {
                LblTitulo.Text = "INGRESO NUEVA FACTURA";
                TxtIdFactura.Text = IdAsignado.ToString();
                TxtFecha.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            }
            else
            {
                LblTitulo.Text = "MODIFICAR FACTURA";
                TxtIdFactura.Text = IdFactura.ToString();
                Llenar_campos();
            }
        }

        private void Llenar_campos()
        {
            dt = factura.Consulta_Factura(IdFactura);
            if (dt == null || dt.Rows.Count == 0)
                return;

            DataRow row = dt.Rows[0];
            TxtCliente.Text = row["StrNombre"].ToString();
            TxtFecha.Text = Convert.ToDateTime(row["DtmFecha"]).ToString("yyyy-MM-dd HH:mm:ss");
            TxtTotal.Text = row["NumValorTotal"].ToString();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            bool valido = true;

            if (string.IsNullOrWhiteSpace(TxtCliente.Text))
            {
                errorProvider1.SetError(TxtCliente, "El cliente es obligatorio.");
                valido = false;
            }
            if (string.IsNullOrWhiteSpace(TxtFecha.Text))
            {
                errorProvider1.SetError(TxtFecha, "La fecha es obligatoria.");
                valido = false;
            }
            if (string.IsNullOrWhiteSpace(TxtTotal.Text))
            {
                errorProvider1.SetError(TxtTotal, "El total es obligatorio.");
                valido = false;
            }
            if (!valido)
                return;

            int idCliente = factura.BuscarIdCliente(TxtCliente.Text.Trim());
            if (idCliente == 0)
            {
                MessageBox.Show("Ese cliente no existe. Escriba el nombre exacto de un cliente de la lista.");
                return;
            }

            factura.C_IdFactura = IdFactura;
            if (IdFactura == 0)
                factura.C_DtmFecha = DateTime.Now;
            else
                factura.C_DtmFecha = DateTime.Parse(TxtFecha.Text);
            factura.C_IdCliente = idCliente;
            factura.C_IdEmpleado = 1;
            factura.C_NumDescuento = 0;
            factura.C_NumImpuesto = 0;
            factura.C_NumValorTotal = double.Parse(TxtTotal.Text);
            factura.C_IdEstado = 1;
            factura.C_StrUsuarioModifica = "Jhorman";

            MessageBox.Show(factura.ActualizarFactura());
            DialogResult = DialogResult.OK;
            Close();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}